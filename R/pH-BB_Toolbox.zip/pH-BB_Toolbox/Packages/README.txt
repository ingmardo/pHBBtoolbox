Package: pH
Type: Package
Title: Misc Functions for Precision Liming Developed by the EIP-Agri pH-BB Project (Brandenburg), Germany
Version: 0.1.2
Date: 2022-01-04
Authors: Ingmar Schroeter (ingmar.schroeter@hnee.de)& Eric Boenecke (boenecke@igzev.de)
Description: The "pH" package provides a set of algorithms and tools for precision liming in Brandenburg (Germany). The required lime (CaO) demand of arable mineral soils is calculated according to the framework scheme provided 
by the Association of German Agricultural Analytic and Research Institutes (VDLUFA). The package also contains an improved stepless approach (Ruehlmann et al., 2021) of the VDLUFA look-up table system and 
provides the instruments required to easily perform the steps necessary to build a complete precision liming processing chain. It comprises functions for: 
(1)sensor data interpolation, (2) optimal soil sampling, (3) soil mapping and (4) the development of prescription maps for variable rate (VRT) liming.

# Installation ----
Install pH_0.1.2.tar.gz file in R Studio under: Tools > Install Packages > Under Install From: select Package Archive File (.zip, .tar.gz) and set path to pH_0.1.2.tar.gz. 
Load the package in R with: 
library(pH)
