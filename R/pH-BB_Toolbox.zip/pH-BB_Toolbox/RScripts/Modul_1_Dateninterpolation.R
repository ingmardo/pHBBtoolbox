#' ---
#' title: "Modul 1 - Dateninterpolation"
#' author: "Ingmar Schröter"
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'     keep_Rmd: true
#'     number_sections: true
#'     fig_caption: true
#' ---
#rm(list = ls(all.names = TRUE))
#knitr::opts_chunk$set(echo = TRUE, cache = T, warning = F, error = F)

# Load packages ----
#+ eval = T
library(pH)
library(raster)
library(sf)
library(leaflet)
library(ggplot2)
library(mapview)
library(ggpubr)
library(scico)
source("RFunctions/gg_multiplot_ras.R")

# 1 Schlaginformationen ----
farm <- "PP"
field <- 1392
schlag.sf <- st_read("Daten/1392/Feldgrenze/PP_1392_Schlaggrenze_Neu.shp")

## 1.1 Schlaggrenze anzeigen ----
m1 <- mapview(schlag.sf[c(2,4,5)], 
              alpha = 0.1,
              alpha.regions = 0.3,
              zcol = "sl_nr", 
              col.regions = c("#FFC125"), 
              layer.name = "Schlaggrenze")
m1

# 2 Dateninterpolation ----  

## 2.1 Veris ECa Daten 2021 ----

### 2.1.1 Daten einlesen ----
ec.sf <- st_read("Daten/1392/Sensorpunktdaten/PP_1392_ECa_Processed_2021-08-04.shp")
date <- "2021-08-04" 

#### Karte Punktdaten  ----
ec_sh.p <-
  ggplot() + 
  geom_sf(data = schlag.sf)+
  geom_sf(data = ec.sf, aes(color = log(ECsh)), alpha = 0.9, size = 0.4) +
  scico::scale_color_scico(palette = 'romaO', na.value="transparent", direction = -1) +
  coord_sf(datum = st_crs(25833))+
  theme_light()+
  labs(title = "Veris MSP3 | ECa Shallow",
       subtitle = paste(farm, field),
       #color = "log(ECa)",
       x = "Easting [m]",
       y= "Northing [m]") 

ec_dp.p <-
  ggplot() + 
  geom_sf(data = schlag.sf)+
  geom_sf(data = ec.sf, aes(color = ECdp), alpha = 0.9, size = 0.4) +
  scico::scale_color_scico(palette = 'roma', na.value="transparent", direction = -1) +
  coord_sf(datum = st_crs(25833))+
  theme_light()+
  labs(title = "Veris MSP3 | ECa Deep",
       subtitle = paste(farm, field),
       #color = "(ECa)",
       x = "Easting [m]",
       y= "Northing [m]") 
ggarrange(ec_sh.p, ec_dp.p, ncol = 1) 

#### Interaktive Karte ---- 
mapview(list(ec.sf[1], ec.sf[2]), cex = 2, lwd = 0, layer.name = c("ECsh", "ECdp"), col.regions = scico(10, palette = 'roma')) 

### 2.1.2 Dateninterpolation ----  
pixel_size <- 2
block_size <- 20 

ec.sel <- as(ec.sf, "Spatial")
akm.ec <- autoKrigMap(x = ec.sel, 
                      boundary = schlag.sf, 
                      block = c(block_size,block_size))

#### Karte Rasterdaten ----
pal <- mapviewPalette("mapviewSpectralColors")
gg_multiplot_ras(x = akm.ec$autoKrigMaps)
#plot(akm.ec$autoKrigMaps, col = pal(100))


#### Interaktive Karte ----
#pal <- mapviewPalette("mapviewTopoColors")
pal <- mapviewPalette("mapviewSpectralColors")
mapview(akm.ec$autoKrigMaps$ECsh, col.regions = pal(100), layer.name = "ECsh") 

### 2.1.3 Speichere Rasterdaten ---- 
file_names <- paste0("Daten/1392/output/Sensorkarten/",farm,"_",field,"_ECsh_BK_",block_size,"x",block_size,"_",date, format=".tif")
writeRaster(akm.ec$autoKrigMaps$ECsh, filename = file_names, bylayer=T, overwrite = T)
# file_names <- paste0("Daten/1392/output/Sensorkarten/",farm,"_",field,"_ECdp_BK_",block_size,"x",block_size,"_",date, format=".tif")
# writeRaster(akm.ec$autoKrigMaps$ECdp, filename = file_names, bylayer=T)

## 2.2 Geophilus ----

### 2.2.1 Daten einlesen ----
gp.sf <- st_read("Daten/1392/Sensorpunktdaten/LPP_1392_EPSG_4326_Geophilus_2017-09-27.shp")
gp.sf <- st_transform(gp.sf, crs = 25833)
date <- "2017-09-27" 

#### Karte Punktdaten  ----
rho1.p <-
  ggplot() + 
  geom_sf(data = schlag.sf)+
  geom_sf(data = gp.sf, aes(color = log(Rho1)), alpha = 0.9, size = 0.4) +
  scico::scale_color_scico(palette = 'romaO', na.value="transparent", direction = -1) +
  coord_sf(datum = st_crs(25833))+
  theme_light()+
  labs(title = "Geophilus | Rho1",
       subtitle = paste(farm, field, "|",date),
       #color = "log(ECa)",
       x = "Easting [m]",
       y= "Northing [m]") 

gamma.p <-
  ggplot() + 
  geom_sf(data = schlag.sf)+
  geom_sf(data = gp.sf, aes(color = Gamma), alpha = 0.9, size = 0.4) +
  scico::scale_color_scico(palette = 'roma', na.value="transparent", direction = -1) +
  coord_sf(datum = st_crs(25833))+
  theme_light()+
  labs(title = "Geophilus | Gamma",
       subtitle = paste(farm, field, "|", date),
       #color = "(ECa)",
       x = "Easting [m]",
       y= "Northing [m]") 
ggarrange(rho1.p, gamma.p, ncol = 1) 

#### Interaktive Karte ---- 
mapview(list(ec.sf[1], ec.sf[2]), cex = 2, lwd = 0, layer.name = c("ECsh", "ECdp"), col.regions = scico(10, palette = 'roma')) 

### 2.2.2 Dateninterpolation ----  
pixel_size <- 2
block_size <- 20 

gp.sel <- as(gp.sf[c("H", "Rho1", "Gamma")], "Spatial")
akm.gp <- autoKrigMap(x = gp.sel, 
                      boundary = schlag.sf, 
                      block = c(block_size,block_size))

#### Karte Rasterdaten ----
gg_multiplot_ras(x = akm.gp$autoKrigMaps)


#### Interaktive Karte ----
#pal <- mapviewPalette("mapviewTopoColors")
pal <- mapviewPalette("mapviewSpectralColors")

mv1 <- mapview(akm.gp$autoKrigMaps$Gamma, 
        col.regions = pal(100), 
        layer.name = c("Gamma")) 

mv2 <- mapview(akm.gp$autoKrigMaps$Rho1, 
          col.regions = pal(100), 
          layer.name = c("Rho1")) 

mv1 + mv2

### 2.2.3 Speichere Rasterdaten ---- 
file_names <- paste0("Daten/1392/output/Sensorkarten/",farm,"_",field,"_Rho1_BK_",block_size,"x",block_size,"_",date, format=".tif")
writeRaster(akm.gp$autoKrigMaps$Rho1, filename = file_names, bylayer=T, overwrite = T)

file_names <- paste0("Daten/1392/output/Sensorkarten/",farm,"_",field,"_Gamma_BK_",block_size,"x",block_size,"_",date, format=".tif")
writeRaster(akm.gp$autoKrigMaps$Gamma, filename = file_names, bylayer=T, overwrite = T)

file_names <- paste0("Daten/1392/output/Sensorkarten/",farm,"_",field,"_H_BK_",block_size,"x",block_size,"_",date, format=".tif")
writeRaster(akm.gp$autoKrigMaps$H, filename = file_names, bylayer=T, overwrite = T)

## 2.3 pH-Manager ----

### 2.3.1 Daten einlesen ----
ph.sf <- st_read("Daten/1392/Sensorpunktdaten/PP_1392_pH_clean_2018-09-10.shp")
ph.sf <- st_transform(ph.sf, crs = 25833)
names(ph.sf)[1] <- "pHS"
date <- "2018-09-10" 

#### Karte Punktdaten  ----

pal1 <- c("#ff5757", "#ff914d", "#ffbd59", "#ffde59", "#c9e265",
          "#03989e", "#2163bb", "#8141a8")

ggplot() + 
  geom_sf(data = schlag.sf)+
  geom_sf(data = ph.sf, aes(color = pHS), alpha = 1, size = 1) +
  #scico::scale_color_scico(palette = 'romaO', na.value="transparent", direction = -1) +
  scale_color_gradientn(colours = pal1)+
  coord_sf(datum = st_crs(25833))+
  theme_light()+
  labs(title = "pH-Manager | pH",
       subtitle = paste(farm, field, "|",date),
       x = "Easting [m]",
       y= "Northing [m]") 

#### Interaktive Karte ---- 
mapview(list(ph.sf[1]), cex = 2, lwd = 0, 
        layer.name = c("pHS"), 
        col.regions = pal1) 

### 2.3.2 Dateninterpolation ----  
pixel_size <- 2
block_size <- 20 

ph.sel <- as(ph.sf[c("pHS")], "Spatial")
akm.ph <- autoKrigMap(x = ph.sel, 
                      boundary = schlag.sf, 
                      block = c(block_size,block_size))

#### Karte Rasterdaten ----
gg_multiplot_ras(x = akm.ph$autoKrigMaps)

#### Interaktive Karte ----
#pal <- mapviewPalette("mapviewTopoColors")
pal <- mapviewPalette("mapviewSpectralColors")

mapview(akm.ph$autoKrigMaps$pHS, 
               col.regions = pal1, 
               layer.name = c("pHS")) 


### 2.3.3 Speichere Rasterdaten ---- 
file_names <- paste0("Daten/1392/output/Sensorkarten/",farm,"_",field,"_pHS_BK_",block_size,"x",block_size,"_",date, format=".tif")
writeRaster(akm.ph$autoKrigMaps$pHS, filename = file_names, bylayer=T, overwrite = T)

## 2.4 OpticMapper ----

### 2.4.1 Daten einlesen ----
om.sf <- st_read("Daten/1392/Sensorpunktdaten/PP_1392_OpticMapper_Processed_2021-08-04.shp")
date <- "2021-08-04" 

#### Karte Punktdaten  ----
pal <- c("#701c00", "#8c3800", "#a85400", "#c47000", "#c48c1c", "#e0a81c", "#e0c48c", "#e0e0e0" , "#c4c4c4", "#8ca8c4", "#708ca8", "#1c54a8", "#385438", "#38381c")

ir.p <- 
ggplot() + 
  geom_sf(data = schlag.sf)+
  geom_sf(data = om.sf, aes(color = IR), alpha = 1, size = 1) +
  scale_color_gradientn(colours = pal)+
  #scico::scale_color_scico(palette = 'romaO', na.value="transparent", direction = -1) +
  coord_sf(datum = st_crs(25833))+
  theme_light()+
  labs(title = "OpticMapper | IR",
       subtitle = paste(farm, field, "|",date),
       x = "Easting [m]",
       y= "Northing [m]") 

red.p <- 
  ggplot() + 
  geom_sf(data = schlag.sf)+
  geom_sf(data = om.sf, aes(color = Red), alpha = 1, size = 1) +
  scale_color_gradientn(colours = pal)+
  coord_sf(datum = st_crs(25833))+
  theme_light()+
  labs(title = "OpticMapper | Red",
       subtitle = paste(farm, field, "|",date),
       x = "Easting [m]",
       y= "Northing [m]") 
ggarrange(red.p, ir.p, ncol = 1) 

#### Interaktive Karte ---- 
mapview(list(om.sf[1], om.sf[2]), cex = 2, lwd = 0, 
        layer.name = c("Red", "IR"), 
        col.regions = pal) 

### 2.4.2 Dateninterpolation ----  
pixel_size <- 2
block_size <- 20 

om.sel <- as(om.sf[c("Red", "IR")], "Spatial")
akm.om <- autoKrigMap(x = om.sel, 
                      boundary = schlag.sf, 
                      block = c(block_size,block_size))

#### Karte Rasterdaten ----
gg_multiplot_ras(x = akm.om$autoKrigMaps)

#### Interaktive Karte ----
mapview(akm.om$autoKrigMaps$IR, 
        col.regions = pal, 
        layer.name = c("IR")) 


### 2.4.3 Speichere Rasterdaten ---- 
file_names <- paste0("Daten/1392/output/Sensorkarten/",farm,"_",field,"_IR_BK_",block_size,"x",block_size,"_",date, format=".tif")
writeRaster(akm.om$autoKrigMaps$IR, filename = file_names, bylayer=T, overwrite = T)

file_names <- paste0("Daten/1392/output/Sensorkarten/",farm,"_",field,"_Red_BK_",block_size,"x",block_size,"_",date, format=".tif")
writeRaster(akm.om$autoKrigMaps$Red, filename = file_names, bylayer=T, overwrite = T)

# Ende ----
