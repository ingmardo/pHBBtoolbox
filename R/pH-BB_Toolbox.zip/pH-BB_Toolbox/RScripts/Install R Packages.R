---
# Installation aller R Packete für die pH-BB Toolbox
# Datum: 14-11-2023
# Ingmar Schröter (HNE Eberswalde; ingmar.schroeter@hnee.de)
---

install.packages("dplyr", lib="C:/Program Files/R/R-4.3.2/library")
install.packages("raster", lib="C:/Program Files/R/R-4.3.2/library")
install.packages("sf", lib="C:/Program Files/R/R-4.3.2/library")
install.packages("ggplot2", lib="C:/Program Files/R/R-4.3.2/library")
install.packages("leaflet", lib="C:/Program Files/R/R-4.3.2/library")
install.packages("scico", lib="C:/Program Files/R/R-4.3.2/library")
install.packages("ggpubr", lib="C:/Program Files/R/R-4.3.2/library")
install.packages("e1071", lib="C:/Program Files/R/R-4.3.2/library")
install.packages("tidyverse", lib="C:/Program Files/R/R-4.3.2/library")
install.packages("mapview", lib="C:/Program Files/R/R-4.3.2/library")
install.packages("gstat", lib="C:/Program Files/R/R-4.3.2/library")
install.packages("concaveman", lib="C:/Program Files/R/R-4.3.2/library")
install.packages("caret", lib="C:/Program Files/R/R-4.3.2/library")
install.packages("patchwork", lib="C:/Program Files/R/R-4.3.2/library")
install.packages("soiltexture", lib="C:/Program Files/R/R-4.3.2/library")
install.packages("randomForest", lib="C:/Program Files/R/R-4.3.2/library")
install.packages("leaps", lib="C:/Program Files/R/R-4.3.2/library")
install.packages("compositions", lib="C:/Program Files/R/R-4.3.2/library")


# Eventuell wird noch Rtools43 for Windows benötigt 
# https://cran.rstudio.com/bin/windows/Rtools/rtools43/rtools.html

install.packages("Packages/maptools_1.1-1.tar.gz", 
                 repos = NULL, type = "source", lib="C:/Program Files/R/R-4.3.2/library")
install.packages("Packages/pH_0.1.2.tar.gz", 
                 repos = NULL, type = "source", lib="C:/Program Files/R/R-4.3.2/library")

