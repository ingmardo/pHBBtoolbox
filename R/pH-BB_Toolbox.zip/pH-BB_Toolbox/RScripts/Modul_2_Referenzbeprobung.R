#' ---
#' title: "Modul 2 - Referenzbeprobung"
#' author: "Ingmar Schröter"
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'     keep_Rmd: true
#'     number_sections: true
#'     fig_caption: true
#' ---
#rm(list = ls(all.names = TRUE))
#knitr::opts_chunk$set(echo = TRUE, cache = T, warning = F, error = F)

# Load packages ----
#+ eval = T
library(pH)
library(raster)
library(sf)
library(leaflet)
library(ggplot2)
library(mapview)
library(ggpubr)
library(scico)
source("RFunctions/gg_multiplot_ras.R")

# 1 Schlaginformationen ----
Betrieb <- "PP"
Schlag <- 1392
schlag.sf <- st_read("Daten/1392/Feldgrenze/PP_1392_Schlaggrenze_Neu.shp")

## 1.1 Schlaggrenze anzeigen ----
m1 <- mapview(schlag.sf[c(2,4,5)], 
              alpha = 0.1,
              alpha.regions = 0.3,
              zcol = "sl_nr", 
              col.regions = c("#FFC125"), 
              layer.name = "Schlaggrenze")
m1

# 2 Referenzbeprobung ----  

## 2.1 Rasterdaten einlesen ---- 
cov.st <- createRasterStack(path = "Daten/1392/output/Sensorkarten/", y = schlag.sf)

# Layernamen 
l <- data.frame(strsplit(names(cov.st), split = "_"))
df <- data.frame(matrix(unlist(l), nrow=length(l), byrow=TRUE))
names(cov.st) <- df[,3]
plot(cov.st, col = scico(100, palette = 'roma'))

## 2.2 pH-Probenahme ----
var <- cov.st[[c("pHS")]]
anzahl <- 10
abstand <- 20
parameter <- "pH"
datum <- "2018-09-10"

ph_proben <- sampleFromStack(x = var, size = anzahl, minmax = 2, buffer = abstand) 

#gg.multiplot.sf(x = var, y = ph_proben$SamplingPointsSF)
pal1 <- c("#ff5757", "#ff914d", "#ffbd59", "#ffde59", "#c9e265",
          "#03989e", "#2163bb", "#8141a8")

pal <- c("#701c00", "#8c3800", "#a85400", "#c47000", "#c48c1c", "#e0a81c", "#e0c48c", 
         "#e0e0e0" , "#c4c4c4", "#8ca8c4", "#708ca8", "#1c54a8", "#385438", "#38381c")


m1 <- mapview(ph_proben$SamplingPointsSF[3], layer.name = "Referenzproben")
m2 <- mapview(var, col.regions = pal, layer.name = c("pHS")) 
m1 + m2 


## 2.3 Speichere Referenzprobenpunkte ----
ph_proben <- ph_proben$SamplingPointsSF[3]
ph_proben$Datum <- datum
ph_proben$Param <- parameter  
ph_proben$Betrieb <- farm
ph_proben$Schlag <- field

pdf(paste0("Daten/1392/output/Probenahmepunkte/",Betrieb,"_",Schlag,"_Probenahmepunkte_",parameter,"_","N_",anzahl, "_", datum,".pdf"), useDingbats=FALSE, width = 11.69, height = 8.27)
ggplot()+
  geom_raster(data = as.data.frame(var, xy=T), aes(x,y,fill = pHS))+
  scale_fill_gradientn(colours = pal, na.value = NA)+
  geom_sf(data = ph_proben, size=6)+
  geom_sf_text(data = ph_proben, aes(label = ID), size = 4, color = "white")+ 
  coord_sf(datum = st_crs(25833))+
  labs(title = paste("pH-Referenzproben"),
       subtitle = paste(Betrieb,Schlag, "|", datum))+
  theme_bw()
dev.off()

sessionInfo()
# Ende ----
