#' ---
#' title: "Modul 3 - Bodenkartenerstellung"
#' subtitle: "pH"
#' author: "Ingmar Schröter, Eric Bönecke"
#' date: "`r Sys.Date()`"
#' output:
#'    pdf_document:
#'     number_sections: true
#'     latex_engine: xelatex
#' ---

# Load packages ----
library(sf)
library(raster)
library(leaflet)
library(ggplot2)
library(pH)
library(patchwork)
library(ggpubr)

# Load helper functions ----
source("C:/HNE-Ingmar/R_Projects/pHBB-Toolbox/R/predictSoilVar.R")
source("C:/HNE-Ingmar/R_Projects/pHBB-Toolbox/R/gg_raster_ph.R")
source("C:/HNE-Ingmar/R_Projects/pHBB-Toolbox/R/validation.R")
source("C:/HNE-Ingmar/R_Projects/00_Funktionen/gg.multiplot.ras.R")

#' # Eingabe der Schlaginformationen 
Betrieb <- "PP"      
Schlag <- "1392"

#' # Importiere Schlaggrenze als Shapefile 
#+ eval = T
schlag.sf <- st_read("Daten/1392/Feldgrenze/PP_1392_Schlaggrenze_Neu.shp")

#' ## Schlaggrenze mit Leaflet anzeigen
#+ eval = T
schlag.wgs84 <- st_transform(schlag.sf, crs=4326)
leaflet() %>%
  addProviderTiles(providers$Esri.WorldImagery) %>%
  addPolygons(data = schlag.wgs84,
              fillOpacity=0.5, stroke=F)

#' # Humuskartenerstellung 

#' ## Importiere Labordaten als Shapefile oder CSV-Datei   

#' Eine CSV-Datei kann nur eingeladen werden, wenn die Spaltennamen x, y und pH existieren. Ein Shapefile muss in der Attributtabelle den Spaltennamen pH enthalten. Es ist zwingend erforferlich, dass der USER das Datum der Probenahme in eine Eingabemaske einträgt.
#'  

#' ### Eingabefeld für Corg Labordaten  
Datum <- "10.09.2018"    
date <- as.Date(Datum, format =  "%d.%m.%Y")

#' ## Lade CSV-Datei
lab.df <- read.csv("Daten/1392/Labordaten/PP_1392_pH_Labor_LKV_2018-09-10.csv", header = T)
#lab.sf <- st_as_sf(lab.df, coords = c("x", "y"), crs=25833)
#st_write(lab.sf,"Daten/1392/Labordaten/PP_1392_pH_Labor_LKV_2018-09-10.shp")

if("pH" %in% colnames(lab.df)){
  cat("Spalte: pH verwendet!\n")
  lab.df <- lab.df[,c("x", "y", "pH")]
} else {
  stop("Es gibt keinen Spaltennamen namens pH.")
}
head(lab.df)

#' ## Lade Shapefile
lab.sf <- st_read("Daten/1392/Labordaten/PP_1392_pH_Labor_LKV_2018-09-10.shp")

if("pH" %in% colnames(lab.sf)){
  cat("Spalte: pH verwendet!\n")
  lab.sf <- lab.sf[,c("pH")]
} else {
  stop("Es gibt keinen Spaltennamen namens pH.")
}

lab.df <- data.frame(st_coordinates(lab.sf), st_drop_geometry(lab.sf))
names(lab.df)[1:2] <- c("x", "y")  


#' ##  Importiere Rasterdaten als GeoTiff 
#' Ein Import Botton ermöglicht die Auswahl und den gleichzigen Upload von Rasterdaten, welche als 
#' Covariate für die Erstellung eines Regressionsmodells zur Humusvorhersage dienen.  

#+ eval=F
# Erzeuge RasterStack von Input 
sensor.st <- createRasterStack(path = "Daten/1392/Sensorkarten/", y = schlag.sf)

# Umbenennung der RaterLayer Namen   
file.names <- names(sensor.st)
layernames.ls <- stringr::str_split(file.names, "_")
layernames.df <- do.call("rbind", layernames.ls)
names(sensor.st) <- layernames.df[,3]

#+ eval=T
# Visualisiere RasterStack 
gg.multiplot.ras(x = sensor.st, cols = 3)

#' # Action Button - Starte Modellrechnung 
#+ eval=F, label = "Action" 
soilVar.pred <- predictSoilVar(lab = lab.df, covars = sensor.st, response = names(lab.df)[3], crs = 25833)

# Setze Pfad zur temp directory wo sich Inpurdaten befinden ----
path <- "Daten/1392/" 

# Erzeuge Output Folder ---- 
dir.create(paste0(path, "/", "output"))

# Vergleiche Validierungsergebnisse  
soilVar.pred$CompareModels

# Scatterplot Matrix 
#soilVar.pred$SPLOM

# Select best model 
soilVar.pred$CompareModels[caret::tolerance(x = soilVar.pred$CompareModels, metric = "RMSE", tol = 2, maximize = F),]
model <- soilVar.pred$CompareModels[caret::tolerance(x = soilVar.pred$CompareModels, metric = "RMSE", tol = 2, maximize = F),][5]
model <- as.character(model)
best.map <- soilVar.pred[model]
list_object <- length(best.map[[1]]) 

# Extract validation results of best soil prediction model 
val.df <- soilVar.pred$CompareModels[soilVar.pred$CompareModels$Model == model,]

# Extract map of best soil prediction model 
map <- best.map[[1]][[list_object]] 

if (is.null(map[map <= 0])){
  map[map <= 0] <- NA
}

#+ eval=T
# Visualisiere Humus oder TOC Karte ----
target <- names(lab.df)[3]
target
ph_map <- gg_raster_ph(data = map, sub = Schlag, name = target)
ph_map

#+ eval=T
# Speichere Humus Raster als GeoTiff ----
file_name <- paste0(path,"output/",Betrieb,"_",Schlag,"_",target,"_", model,"_",date, format=".tif")
file_name
writeRaster(map, filename = file_name, overwrite = T)

# Visualisiere Kalibrationsergebnisse ----  
cal <- validation(pred = map, obs = lab.df, title = "Calibration", var = "pH")
cal_map <- cal$ScatterPlot

# Tabelle mit Validierungsergebnissen ----
main.title <- "Validierungsergebnisse"
subtitle <- paste0(
  "Ergebnis der unabhängigen Validierung der vorhergesagten pH-Karte anhand der Labordaten.") %>%
  strwrap(width = 78) %>%
  paste(collapse = "\n")
val_tab <- ggtexttable(val.df, rows = NULL, theme = ttheme("mOrange")) 
val_tab <- val_tab %>% 
  tab_add_title(text = subtitle, face = "plain", size = 9) %>%
  tab_add_title(text = main.title, face = "bold", padding = unit(0.1, "line"), size =11)

#+ fig.width=8, fig.height=11
# PDF Report ----
ph_map + cal_map + val_tab + plot_layout(ncol = 1)
ggsave(paste0(path,"/output/",Betrieb,"_",Schlag,"_",target,"_",date,"_Report.pdf"), 
       width = 8.27, height = 11.69)

# Ende ----

# Report 
#knitr::opts_chunk$set(cache = T)
#knitr::opts_chunk$set(echo=FALSE, results="hide",fig.width=8, fig.height=6) # nur Abbildungen werden geplottet
#knitr::opts_chunk$set(echo=T, warning=FALSE, message=FALSE, eval=TRUE, fig.width=8, fig.height=6)
#knitr::opts_chunk$set(echo=T, results="hide",fig.width=8, fig.height=6) # nur Abbildungen werden geplottet
#library(rmarkdown)
#library(knitr)
#rmarkdown::render("Modul_3_Bodenkartenerstellung_pH.R", c("html_document"))
#rmarkdown::render("Modul_3_Bodenkartenerstellung_pH.R", c("pdf_document"))
# spin("Modul_3_Bodenkartenerstellung_.R", knit = F)
