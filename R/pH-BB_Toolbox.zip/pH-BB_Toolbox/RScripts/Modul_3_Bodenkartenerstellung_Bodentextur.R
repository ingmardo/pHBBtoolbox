#' ---
#' title: "Modul 3 - Bodenkartenerstellung"
#' subtitle: "Bodentextur"
#' author: "Ingmar Schröter, Eric Bönecke"
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'     keep_Rmd: true
#'     number_sections: true
#' ---

# Load packages ----
library(sf)
library(raster)
library(leaflet)
library(ggplot2)
library(pH)
library(patchwork)
library(ggpubr)

# Load helper functions ----
source("C:/HNE-Ingmar/R_Projects/pHBB-Toolbox/R/predictSoilTextureV2.R")
source("C:/HNE-Ingmar/R_Projects/pHBB-Toolbox/R/gg_raster_soiltexture.R")
source("C:/HNE-Ingmar/R_Projects/pHBB-Toolbox/R/gg_raster_vdlufa.R")
source("C:/HNE-Ingmar/R_Projects/pHBB-Toolbox/R/validation.R")
source("C:/HNE-Ingmar/R_Projects/00_Funktionen/gg.multiplot.ras.R")

#' # Eingabe der Schlaginformationen 
Betrieb <- "PP"      
Schlag <- "1392"

#' # Importiere Schlaggrenze als Shapefile 
#+ eval = T
schlag.sf <- st_read("Daten/1392/Feldgrenze/PP_1392_Schlaggrenze_Neu.shp")

#+ eval = T
#' ## Schlaggrenze mit Leaflet anzeigen
schlag.wgs84 <- st_transform(schlag.sf, crs=4326)
leaflet() %>%
  addProviderTiles(providers$Esri.WorldImagery) %>%
  addPolygons(data = schlag.wgs84,
              fillOpacity=0.5, stroke=F)

#' # Texturkartenerstellung 

#' ## Importiere Labordaten als Shapefile oder CSV-Datei   

#' Eine CSV-Datei kann nur eingeladen werden, wenn die Spaltennamen x, y und Sand-, Schluff- und Tongehalte existieren. Ein Shapefile muss in der Attributtabelle die Spaltennamen Sand-, Schluff- und Tongehalt enthalten. Es ist zwingend erforferlich, dass der USER das Datum der Probenahme in eine Eingabemaske eintr?gt.
#'  

#' ### Eingabefeld f?r Textur-Labordaten  
Datum <- "10.09.2018"    
date <- as.Date(Datum, format =  "%d.%m.%Y")

#' ### Lade CSV-Datei oder Shapefile 
lab.data <- read.csv("Daten/1392/Labordaten/PP_1392_Bodentextur_Labor_TUBerlin.csv", header = T)
lab.data <- st_read("Daten/1392/Labordaten/PP_1392_Bodentextur_Labor_TUBerlin.shp")

if (class(lab.data)[1] == "sf"){
  lab.data <- data.frame(st_coordinates(lab.data), st_drop_geometry(lab.data))
  names(lab.data)[1:2] <- c("x", "y")  
}

if("Ton" %in% colnames(lab.data) & "Schluff" %in% colnames(lab.data) & "Sand" %in% colnames(lab.data)){
  cat("Spalten: Ton, Schluff und Sand verwendet!\n")
  lab.df <- lab.data[,c("x", "y", "Ton", "Schluff", "Sand")]
} else {
  stop("Es gibt keine Spaltennamen namens Ton, Schluff und Sand.")
}
head(lab.df)


#' ##  Importiere Rasterdaten als GeoTiff 

#' Ein Import Botton erm?glicht die Auswahl und den gleichzeitigen Upload von Rasterdaten, welche als Covariate f?r die Erstellung eines Regressionsmodells zur Sch?tzung der Bodentextur dient.  

#+ eval=T
# Erzeuge RasterStack von Input 
sensor.st <- createRasterStack(path = "Daten/1392/Sensorkarten/", y = schlag.sf)

# Umbenennung der RaterLayer Namen   
file.names <- names(sensor.st)
layernames.ls <- stringr::str_split(file.names, "_")
layernames.df <- do.call("rbind", layernames.ls)
layernames.df
names(sensor.st) <- layernames.df[,3]

#+ eval=T
# Visualisiere RasterStack 
pal <- c("#701c00", "#8c3800", "#a85400", "#c47000", "#c48c1c", "#e0a81c", "#e0c48c", 
         "#e0e0e0" , "#c4c4c4", "#8ca8c4", "#708ca8", "#1c54a8", "#385438", "#38381c")
colfunc <- colorRampPalette(pal)
plot(sensor.st, col = colfunc(100))

input <- stack(log(sensor.st$Rho1), sensor.st$SWI, log(sensor.st$ECsh))
names(input) <- c("logRho1", "SWI", "logECsh")

#' # Action Button - Starte Modellrechnung 
#+ eval=T, label = "Action" 
soilVar.pred <- predictSoilTexture(lab = lab.df, covars = input, epsg = 25833)

# Show Maps
soilVar.pred$Maps

# Show Validation results
soilVar.pred$Validation

# Setze Pfad zur temp directory wo sich Inpurdaten befinden ----
path <- "Daten/1392/" 

# Erzeuge Output Folder ---- 
dir.create(paste0(path, "/", "output"))

# Extract validation results of best soil prediction model 
model <- "MLR"
val.df <- soilVar.pred$Validation

#+ eval=T
# Create Texture Maps ----
tex_map <- gg_raster_soiltexture(data = soilVar.pred$Maps[[c("Ton", "Schluff", "Sand")]]) 
vdlufa_map <- gg_raster_vdlufa(data = soilVar.pred$Maps[[4]])

#+ eval=F
# Speichere Bodentexturraster als GeoTiff ----
file_name <- paste0(path,"output/",Betrieb,"_",Schlag,"_",names(soilVar.pred$Maps)
,"_", model,"_",date, format=".tif")
file_name
writeRaster(soilVar.pred$Maps[[1]], filename = file_name[[1]], overwrite = T)
writeRaster(soilVar.pred$Maps[[2]], filename = file_name[[2]], overwrite = T)
writeRaster(soilVar.pred$Maps[[3]], filename = file_name[[3]], overwrite = T)
writeRaster(soilVar.pred$Maps[[4]], filename = file_name[[4]], overwrite = T)

#+ eval=T
# Create Calibration Plots ----
validation(pred = soilVar.pred$Maps$Ton, obs = lab.df[,c("x","y","Ton")], title = "Calibration", var = "Ton")
ton.val <- validation(obs = lab.df[,c("x","y","Ton")], pred = soilVar.pred$Maps$Ton, var = "Ton", title = "Ton")
schluff.val <- validation(obs = lab.df[,c("x","y","Schluff")], pred = soilVar.pred$Maps$Schluff, var = "Schluff", title = "Schluff")
sand.val <- validation(obs = lab.df[,c("x","y","Sand")], pred = soilVar.pred$Maps$Sand, var = "Sand", title = "Sand")
cal_plots <- ton.val$ScatterPlot + schluff.val$ScatterPlot + sand.val$ScatterPlot

#+ eval=T, fig.width=8, fig.height=11
# Tabelle mit Validierungsergebnissen ----
main.title <- "Validierungsergebnisse"
subtitle <- paste0(
  "Ergebnis der unabh?ngigen Validierung der vorhergesagten Bodentexturkarten anhand der Labordaten.") %>%
  strwrap(width = 78) %>%
  paste(collapse = "\n")
val_tab <- ggtexttable(val.df, rows = NULL, theme = ttheme("mOrange")) 
val_tab <- val_tab %>% 
  tab_add_title(text = subtitle, face = "plain", size = 9) %>%
  tab_add_title(text = main.title, face = "bold", padding = unit(0.1, "line"), size =11)


#' ## Erzeuge PDF Report  

#+ eval=T, fig.width=8, fig.height=11
# Display Soil Maps (with patchwork)
map1 <- (tex_map + vdlufa_map) + plot_layout(ncol = 4)
map1 / cal_plots / val_tab  
ggsave(paste0(path,"/output/",Betrieb,"_",Schlag,"_","Bodentextur","_",date,"_Report.pdf"), 
       width = 8.27, height = 11.69)

# Ende ----

# Report 
#knitr::opts_chunk$set(cache = T)
#knitr::opts_chunk$set(echo=FALSE, results="hide",fig.width=8, fig.height=6) # nur Abbildungen werden geplottet
#knitr::opts_chunk$set(echo=T, warning=FALSE, message=FALSE, eval=TRUE, fig.width=8, fig.height=6)
#knitr::opts_chunk$set(echo=T, results="hide",fig.width=8, fig.height=6) # nur Abbildungen werden geplottet
#library(rmarkdown)
#library(knitr)
#rmarkdown::render("Modul_3_Bodenkartenerstellung_Bodentextur.R", c("html_document"))
#rmarkdown::render("Modul_3_Bodenkartenerstellung_Bodentextur.R", c("pdf_document"))
# spin("Modul_3_Bodenkartenerstellung_.R", knit = F)
