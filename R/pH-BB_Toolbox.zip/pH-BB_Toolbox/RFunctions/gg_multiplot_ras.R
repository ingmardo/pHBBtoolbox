library(grid)
library(scico)
library(dplyr)
library(raster)

multiplot <- function(..., plotlist=NULL, file, cols=1, layout=NULL) {
  
  # Make a list from the ... arguments and plotlist
  plots <- c(list(...), plotlist)
  
  numPlots = length(plots)
  
  # If layout is NULL, then use 'cols' to determine layout
  if (is.null(layout)) {
    # Make the panel
    # ncol: Number of columns of plots
    # nrow: Number of rows needed, calculated from # of cols
    layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
                     ncol = cols, nrow = ceiling(numPlots/cols))
  }
  
  if (numPlots==1) {
    print(plots[[1]])
    
  } else {
    # Set up the page
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(nrow(layout), ncol(layout))))
    
    # Make each plot, in the correct location
    for (i in 1:numPlots) {
      # Get the i,j matrix positions of the regions that contain this subplot
      matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE))
      
      print(plots[[i]], vp = viewport(layout.pos.row = matchidx$row,
                                      layout.pos.col = matchidx$col))
    }
  }
}

gg_multiplot_ras <- function(x, cols = 2, alpha = 1){
  
  # Convert RasterStack to DataFrame ----
  df <- raster::as.data.frame(x, xy = T)
  
  plot.list <- list()
  nm <- colnames(dplyr::select(df, !c("x", "y")))
  
  for (i in seq_along(nm)) {
    plot.list[[i]] <- 
      ggplot()+
      geom_raster(aes_string(x = "x" , y = "y", fill =  nm[i]), alpha = 0.8, data = df)+
      scico::scale_fill_scico(palette = 'roma', 
                              na.value="transparent", 
                              direction = 1,
                              guide = guide_colourbar(title.hjust = 0.5,
                                                      title.vjust = 1.2))+
      theme_void()+
      theme(legend.position = "bottom", legend.key.width = unit(0.8, "cm"), legend.key.height = unit(2, "mm"))+
      coord_sf(datum = st_crs(25833))+
      labs(title = nm[i],fill = "")+
      theme(plot.title = element_text(size=9,  hjust = 0.5))
  }
  multiplot(plotlist = plot.list, cols = cols)
}

