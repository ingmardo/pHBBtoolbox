library(sf)
library(dplyr)
library(data.table)
library(pH)

aggAppRatesAB2 <- function (x, abLine, boundary, cellsize = c(12, 12), zeroval = 0, min = NULL) {
  
  poly_ab <- pH::makePolyFromAB(x = abLine, mask = boundary, rs = cellsize)
  names(x) <- "CaO"
  cao_df <- as.data.frame(rasterToPoints(x))
  colnames(cao_df)[3] <- "CaO"
  cao_df$PointID <- 1:nrow(cao_df)
  cao_sf <- st_as_sf(cao_df,coords = c("x","y"), crs = st_crs(boundary))
  
  poly_ab_sf <- poly_ab[[1]][2]
  st_crs(poly_ab_sf) <- st_crs(boundary)
  st_crs(cao_sf) <- st_crs(boundary)
  cao_cells_sf <- sf::st_intersection(x = poly_ab_sf, y = cao_sf)
  
  DT <- data.table(st_drop_geometry(cao_cells_sf))
  DT_agg <- DT[, .(CaO=mean(CaO, na.rm = T)), by=list(ID)]
  cao_poly_agg <- as_tibble(DT_agg)
  
  cao_poly_ab <- dplyr::inner_join(poly_ab_sf, cao_poly_agg, by = "ID")
  cao_poly_ab$CaO <- round(cao_poly_ab$CaO, 0)
  
  if (length(min) >= 1) {
    cao_poly_ab[cao_poly_ab$CaO < min, 2] <- 0
    cao_poly_ab[cao_poly_ab$CaO <= 0, 2] <- zeroval
  } else {
    cao_poly_ab[cao_poly_ab$CaO <= 0, 2] <- zeroval
  }
  return(cao_poly_ab)
}
