
# MSE 
MSE <- function(obs, pred){
  mse.val <- round(mean((pred - obs)**2), digits = 2)
  return(mse.val)
}


# NSE aka AVE (Amount variance explained based on 1:1 Line)
NSE <- function(obs, pred){
  nse <- round(1-(sum((pred-obs)**2)/(sum((obs -mean(obs))**2))),2)
  return(nse)
}

# RMSE
RMSE <- function(obs, pred){
  return(round(sqrt(mean((pred-obs)**2)), digits = 3))
}

# MAE
MAE <- function(obs, pred){
  return(round(mean(abs(pred-obs)), digits = 3))
}

# KA5  -----
#' KA5.SG()
#' The KA5.SG() function allocates the composition of the soil fractions clay (<0.002 mm), silt (0.002-0.063 mm) and sand (0.063 - 2 mm) to the soil groups according to the German Soil Classification (KA5) of the German Soil Science Society (DBG). More information under details.
#' @param x = Data frame containing the columns CLAY, SILT and SAND (in %).
#' @keywords soil groups, soil fractions, KA5
#' @details
#' 
#' KA5 classes are allocated using the 'points-in-classes'-function of the 'soiltexture' package.
#'
KA5 <- function(x, TEX = TRUE) {
  
  # required packages
  require(compositions)
  
  # set defaults
  tex <- TEX
  
  if (TEX == FALSE) {tex <- FALSE}
  
  #### defaults ####
  df <- x # x <- df
  
  if (tex == TRUE) {
    
    #### check for data composition (100%) ####
    dc <- as.data.frame(acomp(df, parts = c("CLAY", "SILT", "SAND"), total = 100, warn.na = TRUE))
    df$CLAY <- round(dc$CLAY,2)
    df$SILT <- round(dc$SILT,2)
    df$SAND <- round(dc$SAND,2)
    
    #### allocate soil type ####
    # currently to the German soil classification system - KA5
    
    df$KA5 <- NA
    df$KA5[               df$CLAY <=   5                & df$SILT <=  10] = "Ss"
    df$KA5[               df$CLAY <=   5 & df$SILT > 10 & df$SILT <=  25] = "Su2"
    df$KA5[df$CLAY >  5 & df$CLAY <=  17                & df$SILT <=  10] = "St2"
    df$KA5[df$CLAY >  5 & df$CLAY <=   8 & df$SILT > 10 & df$SILT <=  25] = "Sl2"
    df$KA5[               df$CLAY <=   8 & df$SILT > 25 & df$SILT <=  40] = "Su3"
    df$KA5[df$CLAY >  8 & df$CLAY <=  12 & df$SILT > 10 & df$SILT <=  40] = "Sl3"
    df$KA5[               df$CLAY <=   8 & df$SILT > 40 & df$SILT <=  50] = "Su4"
    df$KA5[df$CLAY > 17 & df$CLAY <=  25                & df$SILT <=  15] = "St3"
    df$KA5[df$CLAY > 12 & df$CLAY <=  17 & df$SILT > 10 & df$SILT <=  40] = "Sl4"
    df$KA5[df$CLAY > 17 & df$CLAY <=  25 & df$SILT > 15 & df$SILT <=  30] = "Ls4"
    df$KA5[df$CLAY >  8 & df$CLAY <=  17 & df$SILT > 40 & df$SILT <=  50] = "Slu"
    df$KA5[               df$CLAY <=   8 & df$SILT > 50 & df$SILT <=  80] = "Us"
    df$KA5[df$CLAY > 25 & df$CLAY <=  35                & df$SILT <=  15] = "Ts4"
    df$KA5[df$CLAY > 17 & df$CLAY <=  25 & df$SILT > 30 & df$SILT <=  40] = "Ls3"
    df$KA5[df$CLAY >  8 & df$CLAY <=  17 & df$SILT > 50 & df$SILT <=  65] = "Uls"
    df$KA5[df$CLAY > 17 & df$CLAY <=  25 & df$SILT > 40 & df$SILT <=  50] = "Ls2"
    df$KA5[               df$CLAY <=   8 & df$SILT > 80 & df$SILT <= 100] = "Uu"
    df$KA5[df$CLAY > 35 & df$CLAY <=  45                & df$SILT <=  15] = "Ts3"
    df$KA5[df$CLAY >  8 & df$CLAY <=  12 & df$SILT > 65 & df$SILT <=  92] = "Ut2"
    df$KA5[df$CLAY > 25 & df$CLAY <=  45 & df$SILT > 15 & df$SILT <=  30] = "Lts"
    df$KA5[df$CLAY > 25 & df$CLAY <=  35 & df$SILT > 30 & df$SILT <=  50] = "Lt2"
    df$KA5[df$CLAY > 12 & df$CLAY <=  17 & df$SILT > 65 & df$SILT <=  88] = "Ut3"
    df$KA5[df$CLAY > 17 & df$CLAY <=  30 & df$SILT > 50 & df$SILT <=  65] = "Lu"
    df$KA5[df$CLAY > 17 & df$CLAY <=  25 & df$SILT > 65 & df$SILT <=  83] = "Ut4"
    df$KA5[df$CLAY > 35 & df$CLAY <=  45 & df$SILT > 30 & df$SILT <=  50] = "Lt3"
    df$KA5[df$CLAY > 45 & df$CLAY <=  65                & df$SILT <=  15] = "Ts2"
    df$KA5[df$CLAY > 25 & df$CLAY <=  35 & df$SILT > 65 & df$SILT <=  75] = "Tu4"
    df$KA5[df$CLAY > 30 & df$CLAY <=  45 & df$SILT > 50 & df$SILT <=  65] = "Tu3"
    df$KA5[df$CLAY > 45 & df$CLAY <=  65 & df$SILT > 15 & df$SILT <=  30] = "Tl"
    df$KA5[df$CLAY > 45 & df$CLAY <=  65 & df$SILT > 30 & df$SILT <=  55] = "Tu2"
    df$KA5[df$CLAY > 65 & df$CLAY <= 100                & df$SILT <=  35] = "Tt"
    
  } else {
    
    df$KA5 <- NA
    df$KA5[df$KA5_ID == 1] = "Ss"
    df$KA5[df$KA5_ID == 2] = "Su2"
    df$KA5[df$KA5_ID == 3] = "St2"
    df$KA5[df$KA5_ID == 4] = "Sl2"
    df$KA5[df$KA5_ID == 5] = "Su3"
    df$KA5[df$KA5_ID == 6] = "Sl3"
    df$KA5[df$KA5_ID == 7] = "Su4"
    df$KA5[df$KA5_ID == 8] = "St3"
    df$KA5[df$KA5_ID == 9] = "Sl4"
    df$KA5[df$KA5_ID == 10] = "Ls4"
    df$KA5[df$KA5_ID == 11] = "Slu"
    df$KA5[df$KA5_ID == 12] = "Us"
    df$KA5[df$KA5_ID == 13] = "Ts4"
    df$KA5[df$KA5_ID == 14] = "Ls3"
    df$KA5[df$KA5_ID == 15] = "Uls"
    df$KA5[df$KA5_ID == 16] = "Ls2"
    df$KA5[df$KA5_ID == 17] = "Ts3"
    df$KA5[df$KA5_ID == 18] = "Uu"
    df$KA5[df$KA5_ID == 19] = "Ut2"
    df$KA5[df$KA5_ID == 20] = "Lts"
    df$KA5[df$KA5_ID == 21] = "Lt2"
    df$KA5[df$KA5_ID == 22] = "Ut3"
    df$KA5[df$KA5_ID == 23] = "Lu"
    df$KA5[df$KA5_ID == 24] = "Ut4"
    df$KA5[df$KA5_ID == 25] = "Lt3"
    df$KA5[df$KA5_ID == 26] = "Ts2"
    df$KA5[df$KA5_ID == 27] = "Tu4"
    df$KA5[df$KA5_ID == 28] = "Tu3"
    df$KA5[df$KA5_ID == 29] = "Tl"
    df$KA5[df$KA5_ID == 30] = "Tu2"
    df$KA5[df$KA5_ID == 31] = "Tt"
  }
  
  # librar(soiltexture)
  # dt <- TT.points.in.classes(df, "DE.BK94.TT")
  # head(dt)
  # # select cells with entry (rows and cols) and order the entries
  # dtc <- as.data.frame(which(dt>0, arr.ind=TRUE))
  # dts <- dtc[order(dtc$row),]
  # # select first entry in case of multiple classes for a soil texture
  # dto <- aggregate(dts, by = list(ID = dts$row), FUN = min)
  
  # assign texture classes
  KA5 <- df$KA5
  KA5
  
}

# VDLUFA.SG  -----
#' VDLUFA.SG()
#' The VDLUFA.SG() function allocates the composition of the soil fractions clay (<0.002 mm), silt (0.002-0.063 mm) and sand (0.063 - 2 mm) to the soil groups according to the  VDLUFA soil groups 1 to 5.
#' @param x = Data frame containing the columns CLAY, SILT and SAND (in %) as well as the information about their KA5 soil group allocation.
#' @param region = Character defining the region (as Federal state) of the applied VDLUFA soil group allocation. More information under details
#' @keywords soil groups, soil fractions, VDLUFA
#' @details
#' 
#' The 'region' parameter controls the applied soil group allocation as depended on the differences per Federal state in Germany. Currently for the regions Brandenburg, Sachsen-Anhalt and Mecklenburg-Vorpommern.
#' 
#' The allocation of VDLUFA soil groups is based on the KA5 soil group allocation of the three particle size fractions.
#' 
VDLUFA.SG <- function(x, region = NULL) {
  
  # required packages
  require(soiltexture)
  
  #### defaults ####
  df <- x
  df$IDs <- 1:nrow(df)
  reg <- "Brandenburg"
  
  #### update input variables ####
  
  if (!is.null(region)) reg <- region
  
  #### allocate VDLUFA soil groups ####
  
  #### regions Brandenburg, Sachsen-Anhalt, Mecklenburg-Vorpommern ####
  
  if (reg == "Brandenburg" | reg == "Sachsen-Anhalt" | reg == "Mecklenburg-Vorpommern") {
    
    KA5.VDLUFA.LUT <- data.frame(
      
      #### KA5 IDs ####
      ID = c(1:31),
      
      #### KA5 soil groups ####
      KA5 = c("Ss","Su2", # 1
              "St2","Sl2","Su3","Sl3","Su4", # 2
              "St3","Sl4", # 3
              "Ls4", # 4
              "Slu", # 3
              "Us","Ts4","Ls3","Uls","Ls2","Uu", # 4
              "Ts3", # 5
              "Ut2", # 4
              "Lts","Lt2", # 5
              "Ut3","Lu","Ut4", # 4
              "Lt3","Ts2","Tu4","Tu3","Tl","Tu2","Tt"), # 5
      
      #### MPDs for KA5 ####
      KA5_MPD = c(0.2456,
                  0.1595,
                  0.1262,
                  0.1166,
                  0.0845,
                  0.0684,
                  0.0549,
                  0.0529,
                  0.0481,
                  0.0315,
                  0.0282,
                  0.0275,
                  0.0262,
                  0.0205,
                  0.0183,
                  0.0145,
                  0.0124,
                  0.0120,
                  0.0112,
                  0.0105,
                  0.0085,
                  0.0085,
                  0.0077,
                  0.0057,
                  0.0039,
                  0.0037,
                  0.0036,
                  0.0030,
                  0.0022,
                  0.0013,
                  0.0006),
      
      #### VDLUFA soil group IDs ####
      VDLUFA_SG = c(1,1,
                    2,2,2,2,2,
                    3,3,
                    4,
                    3,
                    4,4,4,4,4,4,
                    5,
                    4,
                    5,5,
                    4,4,4,
                    5,5,5,5,5,5,5),
      
      #### MPDs for VDLUFA ####
      VDLUFA_MPD = c(0.203,0.203,
                     0.091,0.091,0.091,0.091,0.091,
                     0.042,0.042,
                     0.017,
                     0.042,
                     0.017,0.017,0.017,0.017,0.017,0.017,
                     0.005,
                     0.017,
                     0.005,0.005,
                     0.017,0.017,0.017,
                     0.005,0.005,0.005,0.005,0.005,0.005,0.005),
      
      #### VDLUFA soil groups ####
      VDLUFA_symbol = c("S","S",
                        "l'S","l'S","l'S","l'S","l'S",
                        "lS","lS",
                        "sL/uL",
                        "lS",
                        "sL/uL","sL/uL","sL/uL","sL/uL","sL/uL","sL/uL",
                        "tL/T",
                        "sL/uL",
                        "tL/T","tL/T",
                        "sL/uL","sL/uL","sL/uL",
                        "tL/T","tL/T","tL/T","tL/T","tL/T","tL/T","T")
      
    )
    
    # write.table(KA5.VDLUFA.LUT, file = paste0(getwd(),"/KA5_VDLUFA_LUT.csv"), sep = ";", row.names = F)
    
    df1 <- merge(df, KA5.VDLUFA.LUT, by=c('KA5'), all=F)
    
    df2 <- df1[order(df1$IDs),]
    
    VDLUFA_SG <- df2$VDLUFA_SG
    
  }
  
  # extra space for other regions in Germany
  if (reg == "somewhere else") {}
  
  VDLUFA_SG
}


# predictSoilTexture ----
predictSoilTexture <- function(lab, covars, epsg = 25833){
  
  require(sp)
  require(caret)
  require(raster)
  
  if (nlayers(covars) <= 1) {
    covars <- stack(covars[[1]], covars[[1]]^2)
  }
  
  # prepare covariate data ----
  sensor.sp <- as(covars, "SpatialGridDataFrame")
  n.covar <- nlayers(sensor.sp)
  
  # further convert to data.frame
  sensor.df <- as(sensor.sp, Class = "data.frame")
  
  ## (Near-)zero variance analysis ----
  nzv <- caret::nearZeroVar(sensor.df, saveMetrics = TRUE)
  
  # drop nzv layers ----
  sensor.df <- sensor.df[,!nzv[,4]]
  #head(sensor.df)
  
  ## Removing incomplete data pixels ----
  
  # re-order; names of coordinate columns are "s1","s2"
  #covar.df <- cbind(sensor.df[,c("s1","s2")], sensor.df[,!names(sensor.df) %in% c("s1","s2")])
  covar.df <- dplyr::select(sensor.df, s1, s2, everything())
  # GWI
  # covar.df$GWI <- covar.df$Gamma / covar.df$Rho1 * 100
  head(covar.df)
  
  # Exclude pixels that do not have complete covariate data
  covar.df <- covar.df[complete.cases(covar.df[,3:ncol(covar.df)]),]
  message(paste0(nrow(sensor.df) - nrow(covar.df), " pixels removed that do not have complete covariate data"))
  
  # make RasterStack of covariates ----
  covar.st <- covar.df
  gridded(covar.st) <- ~ s1 + s2
  proj4string(covar.st) <- CRS(paste0("+init=epsg:",epsg))
  covar.st <- stack(covar.st) # plot(covar.st)
  
  # select texture fractions ----
  tex.df <- cbind(lab["Sand"], lab["Ton"], lab["Schluff"])
  #tex.df <- na.omit(tex.df)
  
  # recompose data to assure 100% distribution of all fractions ----
  # create a class of the means to analyze compositions in the philosophical framework of the Aitchison Simplex
  tex.comp <- compositions::acomp(tex.df, total = 100, warn.na = TRUE)
  
  # Compute the additive log ratio transform of a (data set of) composition(s), and its inverse
  tex.alr <-  compositions::alr(tex.comp)
  
  # make a spatial points dataframe
  tex.alr.xy = cbind(lab["x"], lab["y"], tex.alr)
  coordinates(tex.alr.xy) <- ~x+y
  
  # Define CRS
  proj4string(tex.alr.xy) <- CRS("+init=epsg:25833")
  
  # Extract sensor data at reference points ----
  extrx <- raster::extract(covar.st, tex.alr.xy)
  tex.alr.xy@data <- cbind(tex.alr.xy@data, extrx)
  
  # Create data frame from spatial points data frame
  tex.alr.df <- as.data.frame(tex.alr.xy)[3:length(tex.alr.xy@data)]
  tex.alr.df <- na.omit(tex.alr.df)
  #head(tex.alr.df)
  
  # create data frame in the size of the sensor's dimension
  stack_tab <- as.data.frame(covar.st, na.rm = TRUE, xy = TRUE)
  #head(stack_tab)
  
  # start modeling of the individual texture fraction ----
  cv.L <- list()
  model.df <- data.frame(ID = integer(),Var = character())
  
  for (g in 1:2) {
    
    # g <- 1
    # define data set including the goal variable clay or sand ----
    lm.dat <- tex.alr.xy@data[c(g,3:length(tex.alr.xy@data))]
    lm.dat <- na.omit(lm.dat)
    
    # define formula including all sensor data
    expr <- parse(text = paste(colnames(lm.dat[2:ncol(lm.dat)]), collapse = '+'))
    #expr <- parse(text = paste(colnames(tex.alr.xy@data[3:length(tex.alr.xy@data)]), collapse = '+'))
    lm.form <- as.formula(paste(colnames(tex.alr.xy@data[g]), "~", expr, sep = ""))
    
    # Set up repeated k-fold cross-validation
    #set.seed(25061983)
    
    # define validation mode depending on the size of the data set
    if (nrow(lm.dat) < 20) {
      train.control <- caret::trainControl("LOOCV", number = 1, selectionFunction = "tolerance")
    } else {
      train.control <- trainControl(method = "repeatedcv", number =  4, repeats = 30, savePredictions = T)
    }
    
    #lm.dat <- arrange(lm.dat,Sand)
    
    
    # Train the model
    step.model <-
      caret::train(lm.form,
                   data = lm.dat,
                   method = "leapBackward",
                   tuneGrid = data.frame(nvmax = 1:n.covar),
                   trControl = train.control)
    
    # best model overview
    bstmod <- round(step.model$results, 4)
    bstmod
    step.model$bestTune
    
    # Select sensor data from the best model
    dts <- summary(step.model$finalModel)
    dts1 <- as.data.frame(dts$which)
    dts2 <- tibble::rownames_to_column(dts1[nrow(dts1), c(2:ncol(dts1))], "rowname")
    dts3 <- reshape2::melt(dts2, id = "rowname")
    dts4 <- subset(dts3, value == TRUE)
    
    lst3 <- unique(as.character(dts4$variable))
    
    # create formula
    expr <- parse(text = paste(lst3, collapse = '+'))
    reg <- as.formula(paste(colnames(lm.dat[1]), "~", expr, sep = ""))
    reg1 <- paste(colnames(lm.dat[1]), " ~ ", expr, sep = "")
    
    # run multiple linear regression model with the selected data on the target variable
    step <- lm(reg, lm.dat)
    
    # train the model
    mdl <- train(reg, data = lm.dat, trControl = train.control, method = "lm")
    
    if (mdl$control$method == "LOOCV"){
      mdl$pred$Resample <- 1
    }
    
    #summary(mdl)
    cv.L[[g]] <- mdl$pred
    names(cv.L)[g] <- colnames(lm.dat[1])
    model.df[g,2] <- reg1
    
    # predict spatial distribution of the target variable
    alr.df <- as.data.frame(predict(step, newdata = stack_tab))
    colnames(alr.df) <- paste0(colnames(tex.alr.xy@data[g]), "_raster_table_alr_pred")
    #head(alr.df)
    
    # combine predicted sand and clay data
    if (g == 1) {
      alr.df.all <- alr.df
    } else {
      alr.df.all <- cbind(alr.df.all,alr.df)
    }
    
    # head(alr.df.all)
  }
  
  # Prepare data to report validation results for sand and clay ----
  cv.pred.df <- data.frame(Sand = cv.L$Sand$pred, Ton = cv.L$Ton$pred)
  cv.obs.df  <- data.frame(Sand = cv.L$Sand$obs, Ton = cv.L$Ton$obs)
  cv.pred.df <- as.data.frame(compositions::alrInv(cv.pred.df))
  cv.obs.df  <- as.data.frame(compositions::alrInv(cv.obs.df))
  cv.L$Sand$pred <- cv.pred.df$Sand
  cv.L$Ton$pred <- cv.pred.df$Ton
  cv.L$Sand$obs <- cv.obs.df$Sand
  cv.L$Ton$obs <- cv.obs.df$Ton
  cv.L$Schluff <- cv.L$Ton
  cv.L$Schluff$pred <- cv.pred.df$V3
  cv.L$Schluff$obs <- cv.obs.df$V3
  
  # Calculate performance indices for cross validation results ----
  
  # Ton
  cv.ton.df <-
    cv.L$Ton %>%
    group_by(Resample) %>%
    summarise(MAE = MAE(obs, pred),
              NSE = NSE(obs, pred),
              RMSE = RMSE(obs, pred)) %>%
    #group_by(Resample) %>%
    summarise(MAE = mean(MAE),
              NSE = mean(NSE),
              RMSE = mean(RMSE)) %>%
    as.data.frame()  %>%
    round(.,3)
  
  # Sand
  cv.sand.df <-
    cv.L$Sand %>%
    group_by(Resample) %>%
    summarise(MAE = MAE(obs, pred),
              NSE = NSE(obs, pred),
              RMSE = RMSE(obs, pred)) %>%
    #group_by(Resample) %>%
    summarise(MAE = mean(MAE),
              NSE = mean(NSE),
              RMSE = mean(RMSE)) %>%
    as.data.frame()  %>%
    round(.,3)
  
  # Schluff
  cv.schluff.df <-
    cv.L$Schluff %>%
    group_by(Resample) %>%
    summarise(MAE = MAE(obs, pred),
              NSE = NSE(obs, pred),
              RMSE = RMSE(obs, pred)) %>%
    #group_by(Resample) %>%
    summarise(MAE = mean(MAE),
              NSE = mean(NSE),
              RMSE = mean(RMSE)) %>%
    as.data.frame()  %>%
    round(.,3)
  
  cv.ton.df$Response <- "Ton"
  cv.sand.df$Response <- "Sand"
  cv.schluff.df$Response <- "Schluff"
  cv.res.df <- rbind(cv.ton.df, cv.schluff.df, cv.sand.df)
  cv.res.df$CVInfo <- mdl$control$method
  cv.res.df$N <- nrow(lab)
  cv.res.df$MAE <- cv.res.df$MAE * 100
  cv.res.df$RMSE <- cv.res.df$RMSE * 100
  cv.res.df$Var <- ""
  cv.res.df$Var[1] <- model.df[2,2]
  cv.res.df$Var[3] <- model.df[1,2]
  cv.res.df$Var[2] <- "Schluff ~ 100 - (Ton + Sand)"
  
  # back transformation ALR
  alr_mat_back <- as.data.frame(compositions::alrInv(alr.df.all))
  
  # rename header
  colnames(alr_mat_back) <- c("Sand.PREDICTED","Ton.PREDICTED", "Schluff.PREDICTED")
  
  # round data to two digits
  alr_mat_back <- round(alr_mat_back*100,1)
  #head(alr_mat_back)
  
  
  # create raster data and stack with estimated textures
  tex.df <- cbind(stack_tab[1:2], alr_mat_back)
  colnames(tex.df)[3:5] <- c("SAND", "CLAY", "SILT")
  # head(tex.df)
  # tex.df.bu1 <- tex.df
  
  #### allocate KA5 soil groups ####
  
  # Define KA5 soil classes for each combination of clay, silt and sand
  tex.df$KA5 <- KA5(tex.df)
  tex.df$VDLUFA_BG <- VDLUFA.SG(tex.df)
  head(tex.df)
  
  # create raster stack
  coordinates(tex.df) <- as.formula("~x+y")
  proj4string(tex.df) <- CRS("+init=epsg:25833")            # muss noch gaendert werden!!!
  #tex.df <- spTransform(tex.df, CRS = CRS(paste("+init=epsg:", epsg.code, sep = "")))
  gridded(tex.df) <- TRUE
  tex.rs <- stack(raster(tex.df[1]), raster(tex.df[2]),raster(tex.df[3]), raster(tex.df[5]))
  names(tex.rs) <- c("Sand", "Ton", "Schluff", "VDLUFA")
  #plot(tex.rs)
  
  # Save Output results ----
  results <- list()
  results$Validation <- cv.res.df
  results$Maps <- tex.rs
  return(results)
  
}

# ----------
# End
# ----------


