
# Color scales for SOM (Humus) ----
color_humus1 <- c("#FFF7BC","#FEC44F","#FE9929","#EC7014","#CC4C02","#993404","#662506","#238443")
color_humus2 <- c("#ffff73","#FEFDC0","#FFC780","#FEAA00", "#A87000","#734D00","#403200","#737300")

gg_raster_humus <- function(data, sub = "", col = color_humus1, name = "Humus"){
  humus.df <- raster::as.data.frame(data, xy = TRUE)
  humus.df <- na.omit(humus.df)
  colnames(humus.df)[3] <- name
  humus.karte <-
    ggplot()+
    geom_raster(aes_string(x = "x", y = "y", fill = name), alpha=1, data = humus.df)+
    coord_equal()+
    scale_fill_gradientn(colours = col)+
    labs(title = "Humuskarte",
         subtitle = sub,
         caption = "Data source: ph-BB; Projektion: UTM ETRS89 33N",
         fill= paste(name, "[%]"),
         x="Easting [m]",
         y="Norhing [m]")+
    theme_bw()
  return(humus.karte)
}
