library(grid)
library(scico)
library(dplyr)
library(raster)

multiplot <- function(..., plotlist=NULL, file, cols=1, layout=NULL) {
  
  # Make a list from the ... arguments and plotlist
  plots <- c(list(...), plotlist)
  
  numPlots = length(plots)
  
  # If layout is NULL, then use 'cols' to determine layout
  if (is.null(layout)) {
    # Make the panel
    # ncol: Number of columns of plots
    # nrow: Number of rows needed, calculated from # of cols
    layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
                     ncol = cols, nrow = ceiling(numPlots/cols))
  }
  
  if (numPlots==1) {
    print(plots[[1]])
    
  } else {
    # Set up the page
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(nrow(layout), ncol(layout))))
    
    # Make each plot, in the correct location
    for (i in 1:numPlots) {
      # Get the i,j matrix positions of the regions that contain this subplot
      matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE))
      
      print(plots[[i]], vp = viewport(layout.pos.row = matchidx$row,
                                      layout.pos.col = matchidx$col))
    }
  }
}

gg_multiplot_vr <- function(x, cols = 2, alpha = 1, name = NULL){
  
  # Convert RasterStack to DataFrame ----
  df <- raster::as.data.frame(x, xy = T)
  
  plot.list <- list()
  nm <- names(x)
  for (i in seq_along(nm)) {
    plot.list[[i]] <- 
      ggplot()+
      geom_raster(aes_string(x = "x" , y = "y", fill =  nm[i]), alpha = 0.8, data = df)+
      scale_fill_gradient(low = "yellow", high = "blue", na.value="transparent")+
      theme_void()+
      coord_sf(datum = st_crs(25833))+
      labs(title = paste(nm[i], "|", name, "[kg/ha]"),fill = "")+
      theme(plot.title = element_text(size=9,  hjust = 0.5))
  }
  multiplot(plotlist = plot.list, cols = cols)
}

