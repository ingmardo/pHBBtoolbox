# -----------------------------------------------------------------------------
# Farbskalen f�r Bodeneigenschaften in pH-BB
# Ingmar Schr�ter (HNE Eberswalde - pH-BB)
# Datum: 27.07.2023
# -----------------------------------------------------------------------------

# pH-Wert ----
color_ph <- c("#FF2900","#FF4A08","#FF7310","#FF9C18","#FFDE20","#E6EE31","#9CBD41","#5A835A","#39526A","#29416A","#183173","#08187B")
limits_ph <-  c(3,9)
breaks_ph <-  c(3, 4, 5, 6, 7, 8, 9)

# pH-Versorgungsstufen nach VDLUFA ---- 
color_vst <- c("#2a1c7e","#4e82d6","#169b3e", "#f9ea1f","#e64415")
labels_vst1 <- c("A","B","C","D","E")
labels_vst2 <- c("sehr niedrig","niedrig","optimal","hoch","sehr hoch")

# VDLUFA Bodengruppe ----
color_VDLUFA <-  c("#FDF8CD","#F5E70B","#D0B473","#E9A803","#C55552","#187802")
labels_VDLUFA <- c(1:6)

# Bodengruppen nach KA5 ----
color_ka5 <- c("#fcfdbf" ,"#fdeeaf" ,"#fedea0" ,"#fece91" ,"#febf84" ,
             "#feaf77" ,"#fe9f6d" ,"#fd8f64" ,"#fa7f5e" ,"#f76f5c", 
             "#f1605d" ,"#e95462" ,"#de4969" ,"#d2416f" ,"#c43b74" ,
             "#b63679" ,"#a8327d" ,"#9a2d80" ,"#8c2981" ,"#7f2481", 
             "#721f81" ,"#641a80" ,"#57147d" ,"#490f79" ,"#3b0f6f" ,
             "#2d115f" ,"#1f104b" ,"#140e37" ,"#0b0824" ,"#040312",
             "#000004")
breaks_ka5 <- c(1:31)
labels_ka5 <- c("Ss", "Su2" ,"St2" ,"Sl2" ,"Su3" ,
                "Sl3" ,"St3" ,"Sl4" ,"Su4" ,"Ls4" ,
                "Ts4" ,"Us","Slu" ,"Ls3" ,"Ts3" ,
                "Uls" ,"Lts" ,"Ls2" ,"Lt2" ,"Uu", 
                "Ut2" ,"Lu", "Ut3" ,"Ts2" ,"Ut4" ,
                "Lt3" ,"Tl", "Tu3" ,"Tu4" ,"Tu2" ,
                "Tt")

# Bodengruppe nach Bodensch�tzung (BSK) ----
color_bsk <- c("#ffff00","#ffffa6", "#ffcc00", "#ffd47a","#ccb31a","#bf801a","#d9d9d9","#808080","#1C7800")  
labels_bsk <- c("S","Sl","lS","SL","sL","L","LT","T", "Mo")

# Organische Bodensubstanz (Humus) ----
color_humus1 <- c("#ffff73","#FEFDC0","#FFC780","#FEAA00", "#A87000","#734D00","#403200","#737300")
color_humus2 <- c("#FFF7BC","#FEC44F","#FE9929","#EC7014","#CC4C02","#993404","#662506","#238443")

# CaO-Gehalt [kg/ha] ----
color_cao <- c("#FFFFBF","#E6F598", "#ABDDA4", "#66C2A5", "#3288BD", "#5E4FA2")

# Convertiere RGB in Hex ----
# rgb2hex <- function(r,g,b) sprintf('#%s',paste(as.hexmode(c(r,g,b)),collapse = ''))
# rgb2hex(0	,0,255)
# col2rgb("blue")

# --------
# Ende 
# --------