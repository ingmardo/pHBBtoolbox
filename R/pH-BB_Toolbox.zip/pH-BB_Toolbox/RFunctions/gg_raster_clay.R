require(patchwork)
#require(ggsn)
require(ggplot2)
require(raster)

gg_raster_clay <- function(data, tit = "Ton" ,sub = ""){
  df <- raster::as.data.frame(data, xy = TRUE)
  df <- na.omit(df)
  colnames(df) <- c("x", "y", "Ton")
  
  clay_map <- 
    ggplot()+
    geom_raster(aes(x=x, y=y, fill=Ton), data = df, alpha = 1)+
    #scale_fill_continuous_sequential(palette = "Lajolla", breaks = c(0,20,40,60,80,100), limits = c(0,100))+
    scale_fill_gradientn(colours = c("#f8f6cf", "#fbf8aa", "#f5ce66", "#ec8450", "#d55341", "#985f56", "#5d5e5e",
                                     "#2f3030"))+
    coord_equal()+
    labs(title = tit,
         subtitle = sub,
         fill= "[%]",
         x="Easting [m]",
         y="Norhing [m]")+
    theme_bw()
  
  return(clay_map)
}  
  

# Add scalebar and north arrow ----
# df <- terra::as.data.frame(data, xy = TRUE)
# df <- na.omit(df)
# df <- df[,c("x", "y", names)]
# colnames(df) <- c("x", "y", "Ton", "Schluff", "Sand")
# 
# # get x and y location for scalebar
# sf <- st_as_sf(df, coords = c("x", "y"), crs = 25833)
# ext <- extent(data)
# x_scale_loc <- ext@xmax
# y_scale_loc <- ext@ymin
# d <- round(((ext@xmax-ext@xmin)/6)/10,0) *10
# 
# ggplot()+
#   geom_tile(aes(x=x, y=y, fill=Ton), data = df)+
#   scale_fill_gradientn(colours = c("#f8f6cf", "#fbf8aa", "#f5ce66", "#ec8450", "#d55341", "#985f56", "#5d5e5e",
#                                    "#2f3030"), 
#                        guide = guide_colourbar(title.hjust = 0.5, title.vjust = 1.2))+
#   coord_equal()+
#   labs(title = names[1],
#        fill= paste(names[1], "[%]"),
#        x="Easting [m]",
#        y="Norhing [m]")+
#   theme_void()+
#   theme(legend.position = "bottom", legend.key.width = unit(0.8, "cm"), legend.key.height = unit(2, "mm"))+
#   theme(plot.title = element_text(size=9,  hjust = 0.5))+
#   ggsn::scalebar(sf, dist = d,
#                  st.bottom = F,
#                  dist_unit = "m", 
#                  st.dist = 0.03, 
#                  st.size = 6, 
#                  height = 0.02,
#                  transform = F, 
#                  model = "WGS84", 
#                  location = "bottomright", 
#                  anchor = c(x = x_scale_loc, y = (y_scale_loc + 200)))+
#   ggsn::north(data = sf, symbol = 10,  scale = 0.1, anchor = c(x = x_scale_loc -400, y = (y_scale_loc + 280)))

