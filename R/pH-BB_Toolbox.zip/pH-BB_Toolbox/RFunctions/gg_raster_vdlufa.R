require(patchwork)
require(ggplot2)

## VDLUFA Bodengruppen Karte ----

gg_raster_vdlufa <- function(data){
  df <- raster::as.data.frame(data, xy = TRUE)
  df <- na.omit(df)
  names(df)[3] <- "VDLUFA"
  df$VDLUFAfact <- factor(df$VDLUFA, levels = 1:6)   
  
  color_VDLUFA <-  c("#FDF8CD","#F5E70B","#D0B473","#E9A803","#C55552","#187802")
  labels_VDLUFA <- paste(c(1:6))
  
  bg_map <- 
    ggplot()+
    geom_tile(aes(x=x, y=y, fill=VDLUFAfact), data = df)+
    scale_fill_manual(values = color_VDLUFA, 
                      limits = labels_VDLUFA,
                      guide = guide_legend(direction = "horizontal",
                                           keyheight = unit(2, units = "mm"),
                                           #keywidth = unit(50 / length(labels), units = "mm"),
                                           title.position = 'top',
                                           title.hjust = 0.5,
                                           label.hjust = 0.5,
                                           nrow = 1,
                                           byrow = T,
                                           reverse = F,
                                           label.position = "bottom")) +
    coord_equal()+
    labs(title = "VDLUFA Bodengruppen",
         #subtitle = "LIH AL",
         #caption = "Data source: LAB; Projektion: UTM ETRS89 33N",
         fill= "BG",
         x="Easting [m]",
         y="Norhing [m]")+
    theme_void(base_size = 13)+
    theme(legend.position = "bottom", legend.key.width = unit(0.8, "cm"), legend.key.height = unit(2, "mm"))+
    theme(plot.title = element_text(size=9,  hjust = 0.5))
    
  return(bg_map)
} 
