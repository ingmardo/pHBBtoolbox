# Validation of Raster Data 
require(raster)
require(ggplot2)
require(sf)

# MSE
MSE <- function(obs, pred){
  mse.val <- round(mean((pred - obs)**2), digits = 2)
  return(mse.val)
}

# NSE aka AVE (Amount variance explained based on 1:1 Line)
NSE <- function(obs, pred){
  nse <- round(1-(sum((pred-obs)**2)/(sum((obs -mean(obs))**2))),2)
  return(nse)
}

# RMSE
RMSE <- function(obs, pred){
  return(round(sqrt(mean((pred-obs)**2)), digits = 3))
}

# MAE
MAE <- function(obs, pred){
  return(round(mean(abs(pred-obs)), digits = 3))
}

# Validation----
validation <- function(obs, pred, var = "Soil Organic Matter", title = ""){
  
  if(class(obs)[1] == "sf"){
    obs <- data.frame(st_coordinates(obs), obs)
    obs$geometry <- NULL
  }
  
  if(class(pred)[1] == "RasterLayer"){
    p <- raster::extract(x = pred, y = obs[,1:2])
  } else {
    p <- pred
  } 
  
  test <- c(obs[,3], p)
  min <- (floor(10*min(test))/10)
  max <- (ceiling(10*max(test))/10)
  df <- data.frame(obs = obs[,3], pred = p)
  
  # Add Annotation
  NSE_val <- round(NSE(obs = obs[,3], pred = p),2)
  RMSE_val <- round(RMSE(obs = obs[,3], pred = p),2)
  MAE_val <- round(MAE(obs[,3], pred = p),2)
  N <- length(p)
  
  # Create Plot
  scatter.p <- 
    ggplot()+
    geom_point(data = df ,aes(x = obs, y = pred), size = 1.8, alpha = 0.6)+
    geom_abline(intercept = 0, slope = 1, color = "#1C86EE", size=1.2)+
    theme_bw()+
    labs(title = title,
         x = paste(var, "Observed"),
         y = paste(var, "Predicted"))+
    xlim(c(min, max))+
    ylim(c(min, max))+
    annotate("text", label =  paste("N =", N, "\n",
                                    "NSE = ", NSE_val, "\n",
                                    "RMSE =",RMSE_val, "\n",
                                    "MAE =", MAE_val, "\n"), 
             x =  Inf, y = -Inf, 
             vjust = "inward", hjust = "inward") 
  results <- list()
  results$performance <- data.frame(NSE = NSE_val, RMSE = RMSE_val, MAE = MAE_val)
  results$ScatterPlot <- scatter.p 
  return(results)
}
