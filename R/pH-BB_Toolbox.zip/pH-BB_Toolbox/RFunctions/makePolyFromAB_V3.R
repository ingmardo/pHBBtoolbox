# ----------------------------------------------------------------------------------------
# Title: Create PolygonGrid aligned and centered to permanent tractor lane(s)  
# Author: Ingmar Schroeter
# Date: 25.09.2020
# Version: 2.0
# ----------------------------------------------------------------------------------------
# Load packages ----
library(raster)
library(sf)
library(ggplot2)
library(dplyr)
library(maptools)
options(digits = 8)
#(rgeos)
#library(dismo)

# -----------------------------------------------------------------------------

makePolyFromAB <- function(x, mask, rs = c(12,40), lf = 1, epsg = 25833){
  # Create PolygonGrid aligned and centered to permanent tractor lanes  
  # Input:
  #   x: object of class sf; Imported Shapefile that contains tractor lanes (lines) of a field.
  #   mask: Spatial object that defines the field boundary or the extent of the field.   
  #   buffer: integer; buffer distance to increase extend of the PolygonGrid 
  #   rs: numeric vectors of length 2, giving the resolution of the PolygonGrid in c(dx,dy) direction.
  #   lf: integer; indicating which line feature (tractor lane) should be selected to perform the 
  #       alignment of the PolygonGrid
  #   epsg: integer; EPSG code numbers. DEFAULT is set to 25833 for Brandenburg. 
  # Output:
  #   list of length 2; containing [1] aligned and centered PolygonGrid as sf object clipped to the extend of    #   the tractor lanes and [2] aligned and centered PolygonGrid as SpatialPolygonsDataFrame without clipping. 
  
  # create raster with specified resolution in x and y  direction ---- 
  ext <- extent(mask)
  buffer.x <- sqrt((ext@xmax-ext@xmin)^2 + (ext@ymax-ext@ymin)^2) - (ext@xmax-ext@xmin)
  buffer.y <- sqrt((ext@xmax-ext@xmin)^2 + (ext@ymax-ext@ymin)^2) - (ext@ymax-ext@ymin)
  buffer <- min(c(buffer.x, buffer.y))
  
  ext@xmin <- round(ext@xmin - buffer)
  ext@ymin <- round(ext@ymin - buffer)
  ext@xmax <- round(ext@xmax + buffer) 
  ext@ymax <- round(ext@ymax + buffer)
  
  # set raster resolution ----
  x.reso <- rs[1] # set resolution for x e.g. 12 m 
  y.reso <- rs[2] # set resolution for y e.g. 40 m 
  xcol <- (ext@xmax - ext@xmin)/x.reso 
  yrow <- (ext@ymax - ext@ymin)/y.reso 
  xmax <- ext[1]+ceiling(xcol)*x.reso 
  ymax <- ext[3]+ceiling(yrow)*y.reso
  ext[2]<- xmax
  ext[4]<- ymax
  xcol <- (ext@xmax - ext@xmin)/x.reso 
  yrow <- (ext@ymax - ext@ymin)/y.reso 
  
  # create raster with c(x,y) resolution 
  basis.r <- raster(ext, yrow, xcol, crs = CRS(paste0("+init=epsg:",epsg))) 
  
  # set RasterCellIDs ----
  basis.r <- setValues(basis.r, 1:ncell(basis.r))
  #plot(basis.r)
  #text(basis.r, col='white', cex=0.1)
  
  # convert raster to polygon --> create PolygonGrid ----
  poly.grid <- rasterToPolygons(basis.r)
  proj4string(poly.grid) <- proj4string(CRS(paste0("+init=epsg:",epsg)))
  plot(poly.grid)
  
  # convert x (tractor lanes) into spatial object (sp) ----
  leit.sp <- as(x, "Spatial")
  plot(leit.sp, add=T, col="red")
  
  # calculate rotation angle in degree ----
  coords <- st_coordinates(x[lf,1])
  tan.a <- (coords[2,2]-coords[1,2])/(coords[2,1]-coords[1,1])
  a.tan <- as.numeric(atan(tan.a)*180/pi)
  a.tan <- as.numeric(format(round(a.tan, 2), nsmall = 2))
  
  # necessary step to rotate to the right or left
  if (a.tan >= 0){
    rot.ang <- (90 - atan(tan.a)*180/pi)
  } else {
    rot.ang <- (90 - abs(a.tan))*(-1) 
  }
  cat("Rotation angle in degree:",rot.ang)
  
  # rotate PolygonGrid ----
  ctr.poly.grid <- apply(bbox(poly.grid), 1, mean) # define center with coordinates for rotation
  poly.grid.rot <- maptools::elide(poly.grid, rotate= rot.ang, center = ctr.poly.grid,  reflect=c(TRUE, TRUE))
  poly.grid.rot$ID <- 1:nrow(poly.grid.rot)
  plot(poly.grid.rot)
  plot(leit.sp, add=T, col="red", cex=0.1)
  proj4string(poly.grid.rot) <- proj4string(poly.grid)
  
  # select line segment (tractor lane) to align PolygonGrid ---- 
  leitsp.bbox <- st_bbox(x[lf,1])
  leitsp.bbox.df <- data.frame(x= c(leitsp.bbox[[1]], leitsp.bbox[[3]]), 
                               y = c(leitsp.bbox[[2]], leitsp.bbox[[4]]))
  
  plot(poly.grid.rot, 
       ylim = c(leitsp.bbox[[2]], leitsp.bbox[[4]]), 
       xlim =  c(leitsp.bbox[[1]],  leitsp.bbox[[3]]))
  plot(x[lf,1], add=T, col = "red")
  #polygonsLabel(poly.grid.rot, labels = poly.grid.rot$ID, method = "buffer", cex=.1)
  
  # Find cells of PolygonGrid that intersect with selected line segment 
  poly.rot.sf <- st_as_sf(poly.grid.rot) # make sf object
  st_crs(poly.rot.sf) <-  st_crs(x)      # set crs 
  poly.inters <- st_intersection(x[lf,1], poly.rot.sf) 
  
  # select one cell (PolygonGrid ID) that intersects with line segment ----  
  #poly.inters[[3]]
  poly.id <- poly.inters[[3]][1] 
  poly.rot.sf[poly.id,]
  
  # plot of selected line segment and PolygonGrid ----
  ggplot() +
    geom_sf(data = poly.rot.sf, fill = "#141414", color = "grey")+
    #geom_sf(aes(fill = ID), data = poly.rot.sf)+
    geom_sf(data = x[lf,1], aes(color = "AB-Line"), color="#FFA500")+
    scale_fill_viridis_c(alpha = .9) +
    geom_sf_text(aes(label = ID), 
                 colour = "white", 
                 data = poly.rot.sf,
                 size=1,
                 angle=90)+
    coord_sf(datum = st_crs(25833))+
    ylim(leitsp.bbox[[2]], leitsp.bbox[[4]])+
    xlim(leitsp.bbox[[1]], leitsp.bbox[[3]])
  
  # select intersected cell of PolygonGrid and extract bbox ----  
  poly.coords <- as.data.frame(st_coordinates(poly.rot.sf[poly.id,]))
  poly.bbox <- st_bbox(poly.rot.sf[poly.id,])
  poly.bbox.df <- data.frame(x= c(poly.bbox[[1]], poly.bbox[[3]]), y = c(poly.bbox[[2]], poly.bbox[[4]]))
  dist(poly.coords)
  
  # select coordinates of vertex with ymin value ----
  # (depending on rotation angle this might be the upper left or upper right corner of the PolygonGrid Cell)
  upper.corner <- poly.coords[poly.coords[,2] == poly.bbox[2],] 
  
  # select coordinates of line segment (AB-line) ----  
  leitsp.coords <- as.data.frame(st_coordinates(x[lf,1]))
  leitsp.coords <- leitsp.coords %>% dplyr::filter(Y == min(Y))
  
  # shift rotated PolygonGrid to match selected line segment (tractor lane) ---- 
  shift.xy <- leitsp.coords[1,1:2]-upper.corner[1,1:2]
  r.rot.shift <- maptools::elide(poly.grid.rot, shift = as.numeric(c(shift.xy[1], shift.xy[2])))
  #plot(r.rot.shift, ylim = c(5813300, 5814600), xlim =  c(457200,  457300))
  plot(r.rot.shift)
  plot(x[lf,1], add=T, col = "red")
  
  # calculate final shift to align line segment to center (in x direction) of PolygonGrid ---- 
  dx <- rs[1]  # length in x direction
  shift.x <- cos((90-abs(a.tan)) * (pi/180)) * (dx/2) 
  shift.y <- sin((90-abs(a.tan)) * (pi/180)) * (dx/2) 
  
  # final shift of rotated PolygonGrid to align line segment to center of dx ----
  if (rot.ang >= 0){
    r.rot.final <- maptools::elide(r.rot.shift, shift=c(shift.x, -shift.y))
  } else {
    r.rot.final <- maptools::elide(r.rot.shift, shift=c(-shift.x, -shift.y))
  }
  
  #plot(x, add=T, col = "red")
  
  # clip data to line segment (tractor lanes) ----
  mask.sp <- as(mask, "Spatial")
  clip.poly  <- raster::intersect(r.rot.final,mask.sp)
  
  # plot final map ----
  clip.poly.sf <- st_as_sf(clip.poly)
  map.result <- 
    ggplot() +
    geom_sf(data = clip.poly.sf, fill = "grey8", color = "grey")+
    scale_fill_viridis_c(alpha = .9) +
    geom_sf(data = x, aes(color = "AB-Line"), color="#FFA500")+
    coord_sf(datum = st_crs(25833))+
    theme_bw()
  print(map.result)
  
  # return list of clipped and unclipped result ----
  return(list(clip.poly.sf, r.rot.final))
}

# -----------------------------------------------------------------------------
# Examples ----
# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------
# Beispiel KL 60 ----
# -----------------------------------------------------------------------------

# Schlaggrenze einladen ----
schlag.gr <- st_read("Data/KL60/60_01_schlaggrenze_2019_etrs98_6.shp")
plot(schlag.gr)

# Leitspur (AB-Linie) einladen ----
leitspur <- sf::read_sf("Data/KL60/60_01_leitspuren_mb_etrs89_6.shp")
plot(leitspur)

# Erzeuge PolygonGrid, welches an AB Linie ausgerichtet ist 
polyAB <- makePolyFromAB(x = leitspur, mask = schlag.gr, rs = c(12,12))

# Plotte Ergebnis 
ggplot() +
  geom_sf(data = polyAB[[1]][2], fill = "grey8", color = "grey")+
  scale_fill_viridis_c(alpha = .9) +
  geom_sf(data = schlag.gr, aes(color = "Boundary", alpha = "BBOX"), color="red")+
  geom_sf(data = leitspur, aes(color = "AB-Line"), color="#FFA500")+
  theme_bw()+
  coord_sf(datum = st_crs(25833))


# -----------------------------------------------------------------------------
# Berechnung CaO-Streukarte ----
# -----------------------------------------------------------------------------

# Aggregiere Cao-Bedarfskarte auf Streuraster (z.B. 12 x 12 m)   
cao.raster <- raster("C:/Users/ischroeter/Nextcloud/AP3_Wissenstransfer_DS/pHBB_Publikationen/Veröffentlichungen/SIPA/MAPS/OUTPUT/CaO/KLZ_0060_CaO02_dt_ha_res2m_epsg25833_date191119.tif") 
cao.raster <- cao.raster*100
plot(cao.raster)
names(cao.raster) <- "CaO_kg_ha"

# Aggregiere aus Streuraster 
cao.sp <- as.data.frame(rasterToPoints(cao.raster))
colnames(cao.sp)[3]<- "CaO_kg_ha"
cao.sp$Point.ID <- 1:nrow(cao.sp)   
coordinates(cao.sp) <- ~ x + y
proj4string(cao.sp) <- proj4string(cao.raster)
cao.sf <- st_as_sf(cao.sp)

poly.ab.sf <- polyAB[[1]][2]
st_crs(poly.ab.sf) <- 25833
st_crs(cao.sf) <- 25833
cao.cells.df <- st_intersection(x = poly.ab.sf,y = cao.sf)

# Aggregate CaO values ----
cao.poly.aggr <-
  cao.cells.df %>%
  group_by(ID) %>% # Gruppiere per CellID des Baisrasters  
  summarise(CaO = mean(CaO_kg_ha, na.rm = T))# Berechne CaO Mittelwert pro Polygon
cao.poly.ab  <- st_join(poly.ab.sf, cao.poly.aggr, by ="ID")
cao.poly.ab <- na.omit(cao.poly.ab)
cao.poly.ab[cao.poly.ab$CaO <= 250,3] <- 0
cao.poly.ab[cao.poly.ab$CaO <= 250,3] <- NA


# Plotte Ergebnis 
ggplot() +
  geom_sf(data = cao.poly.ab, aes(fill = CaO), color = "grey", alpha=0.9)+
  #scale_fill_gradientn(colours = c("#FFFFBF","#E6F598", "#ABDDA4", "#66C2A5", "#3288BD", "#5E4FA2"))+
  scale_fill_viridis_c(alpha = .9) +
  #geom_sf(data = schlag.gr, aes(color = "Boundary", alpha = "BBOX"), color="red")+
  geom_sf(data = leitspur, aes(color = "AB-Line"), color="#FFA500")+
  theme_bw()+
  coord_sf(datum = st_crs(25833))
summary(cao.poly.ab)

# Export CaO-Streuraster
filename <- paste(Betrieb,"_", Schlag, "_", "CaO_Streukarte_",x.reso,"x",y.reso,"_",Datum2,"_ETRS89_33N.tif", sep = "")
filename
writeRaster(streu.r,
            filename= paste("2_Daten/GW21/Ergebnisse/", filename, sep = ""),
            format="GTiff",
            overwrite=TRUE)

# -----------------------------------------------------------------------------
#' ## Anzeige - Cao-Streukarte 12x12 m mit Google-Luftbild
# -----------------------------------------------------------------------------
#+ fig.cap = "CaO-Streukarte in kg/ha - VDLUFA diskret 12x12 m Raster"
Titel <- "KL60"
cao.streukarte <-
  ggplot()+     
  geom_sf(data = cao.poly.ab, aes(fill = CaO), color = "grey", alpha=0.9)+
  #geom_sf(data = schlag.sf, colour = "red", lwd=0.1, fill = alpha("red", 0))+
  scale_fill_gradient(low = "yellow", high = "blue", na.value = NA)+
  #scale_fill_gradientn(colours = col.cao, na.value = "#FF0000FF")+
  coord_sf(datum = st_crs(25833))+
  labs(title = "CaO-Streukarte in kg/ha 12x12 m | VDLUFA diskret",
       subtitle = Titel,
       caption = "Data source: ph-BB; Projektion: UTM ETRS89 33N; Luftbild: Google | DigitalGlobe",
       fill= "CaO [kg/ha]",
       x="Easting [m]",
       y="Norhing [m]")
  # xlim(low= st_bbox(schlag.sf)[1],
  #      high= st_bbox(schlag.sf)[3])+
  # ylim(low= st_bbox(schlag.sf)[2],
  #      high= st_bbox(schlag.sf)[4])
cao.streukarte

# -----------------------------------------------------------------------------
#' Exportiere Kalk-Applikationskarte als KML
# -----------------------------------------------------------------------------
library(plotKML)

cao.poly.ab.wgs <- st_transform(cao.poly.ab, crs = 4326)
streuer.stack.sp <- as(cao.poly.ab.wgs, "Spatial")
names(streuer.stack.sp)[3] <- "SWert"
plotKML::kml(streuer.stack.sp[3], colour = SWert, colour_scale =  RColorBrewer::brewer.pal(11,"Spectral"), file.name = "Data/KL60/KL_60_Streukarte_Sollwert_Kalk_12x12_WGS84.kml", plot.legend = TRUE, legend.file="Data/KL60/kml_legend.png")  

plotKML::kml_legend.bar(x=streuer.stack.sp$SWert, legend.file="Data/KL60/kml_legend.png",  legend.pal = RColorBrewer::brewer.pal(11,"Spectral"))

kml_legend.bar(streuer.stack.sp[[3]], width, height, pointsize = 14, legend.file, legend.pal, 
               z.lim = range(x, na.rm=TRUE, finite=TRUE), factor.labels, png.type = "cairo-png")

plotKML::kml(streuer.stack.sp,
             file.name    = "meuse_cadium.kml",
             points_names = streuer.stack.sp$SWert,
             colour    = "#FF0000",
             alpha     = 0.6,
             size      = 1,
             shape     = "http://maps.google.com/mapfiles/kml/pal2/icon18.png")

# Save PoygonGrid als Shapefile ----
#st_write(polyAB[[1]][2], "C:/Users/ischroeter/Nextcloud/Entwicklung Software/1. Entwicklungsetappe/2_Daten/MakePolyFromAB/Results/KL_6_PolyFromAB.shp")


kml_open("Data/KL60/KL_60.kml")
kml_layer(streuer.stack.sp[3], colour = Swert)
kml_close("Data/KL60/KL_60.kml")
# -----------------------------------------------------------------------------
# Beispiel KL 62 ----
# -----------------------------------------------------------------------------

# Schlaggrenze einladen ----
schlag.gr <- st_read("Data/KL_62_Schlaggrenze.shp")
plot(schlag.gr)

# Leitspur (AB-Linie) einladen ----
leitspur <- sf::read_sf("Data/KL_63_Leitspuren.shp")
plot(leitspur)

# Erzeuge PolygonGrid, welches an AB Linie ausgerichtet ist 
polyAB <- makePolyFromAB(x = leitspur, mask = schlag.gr, rs = c(12,40))

# Plotte Ergebnis 
ggplot() +
  geom_sf(data = polyAB[[1]][2], fill = "grey8", color = "grey")+
  scale_fill_viridis_c(alpha = .9) +
  geom_sf(data = schlag.gr, aes(color = "Boundary", alpha = "BBOX"), color="red")+
  geom_sf(data = leitspur, aes(color = "AB-Line"), color="#FFA500")+
  theme_bw()+
  coord_sf(datum = st_crs(25833))

# Save PoygonGrid als Shapefile ----
#st_write(polyAB[[1]][2], "C:/Users/ischroeter/Nextcloud/Entwicklung Software/1. Entwicklungsetappe/2_Daten/MakePolyFromAB/Results/KL_63_PolyFromAB_V3.shp")


# -----------------------------------------------------------------------------
# Beispiel KL 60 ----
# -----------------------------------------------------------------------------

# Schlaggrenze einladen ----
schlag.gr <- st_read("2_Daten/?bung_KL_60/1_Eingabedaten/KL60_Schlaggrenze.shp")
schlag.gr

# Leitspur (AB-Linie) einladen ----
leitspur <- sf::read_sf("2_Daten/?bung_KL_60/1_Eingabedaten/60_01_leitspuren_mb_etrs89_6.shp")
plot(leitspur)

# Erzeuge PolygonGrid, welches an AB Linie ausgerichtet ist 
polyAB <- makePolyFromAB(x = leitspur, mask = schlag.gr, rs = c(12,40))

# Plotte Ergebnis 
ggplot() +
  geom_sf(data = polyAB[[1]][2], fill = "grey8", color = "grey")+
  scale_fill_viridis_c(alpha = .9) +
  geom_sf(data = schlag.gr, aes(color = "Boundary", alpha = "BBOX"), color="red")+
  geom_sf(data = leitspur, aes(color = "AB-Line"), color="#FFA500")+
  theme_bw()+
  coord_sf(datum = st_crs(25833))

# Save PoygonGrid als Shapefile ----
#st_write(polyAB[[1]][2], "C:/Users/ischroeter/Nextcloud/Entwicklung Software/1. Entwicklungsetappe/2_Daten/MakePolyFromAB/Results/KL_63_PolyFromAB_V3.shp")

# -----------------------------------------------------------------------------
# Beispiel KL 61 ----
# -----------------------------------------------------------------------------

# Schlaggrenze einladen ----
schlag.gr <- st_read("C:/Users/ischroeter/Nextcloud/Datenbank/KL/5_Sensordaten/61/Schlaggrenze/sg_61_2018_erts_6.shp")
schlag.gr
st_crs(schlag.gr) <- 25833

# Leitspur (AB-Linie) einladen ----
leitspur <- sf::read_sf("C:/Users/ischroeter/Nextcloud/Datenbank/KL/5_Sensordaten/61/Spuren/kl_61_leitspur_etrs89_6.shp")
plot(leitspur)

# Erzeuge PolygonGrid, welches an AB Linie ausgerichtet ist 
polyAB <- makePolyFromAB(x = leitspur, mask = schlag.gr, rs = c(12,40))

# Plotte Ergebnis 
ggplot() +
  geom_sf(data = polyAB[[1]][2], fill = "grey8", color = "grey")+
  scale_fill_viridis_c(alpha = .9) +
  geom_sf(data = schlag.gr, aes(color = "Boundary", alpha = "BBOX"), color="red")+
  geom_sf(data = leitspur, aes(color = "AB-Line"), color="#FFA500")+
  theme_bw()+
  coord_sf(datum = st_crs(25833))

# --------
# End ----
# --------