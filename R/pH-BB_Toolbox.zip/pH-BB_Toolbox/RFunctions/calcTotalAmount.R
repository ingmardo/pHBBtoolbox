
# Calculate total amount of lime for field
# x: rasterLayer with CaO amount in kg/ha 
calcTotalAmount <- function(x){
  layer_name <- names(x)
  cao_int <- round(x,0) # Sollwerte als Integer
  names(cao_int) <- layer_name
  cao_sk_df <- as.data.frame(cao_int, xy=T)
  cao_sk_df <- na.omit(cao_sk_df)
  a <- raster::res(x)[1] * raster::res(x)[2] # Pixel area
  cao_sk_df$area <- a
  cao_sk_df$amount <- cao_sk_df[,3] *(cao_sk_df$area/10000) 
  amount <- round(sum(cao_sk_df$amount)/1000,1)
  message("Fuer den gesamten Schlag muessen ", amount, " Tonnen Kalk bestellt werden.")
  return(amount)
}
