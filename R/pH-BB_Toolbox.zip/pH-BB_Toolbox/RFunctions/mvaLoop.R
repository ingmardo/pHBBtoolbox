#' @title Moving average of spatial point data
#' @description This function calculates the moving average of input spatial point data based on a pre-defined search radius.
#' @param data A DataFrame starting with x and y UTM-coordinates and numeric variables.
#' @param radius Numeric value. Selects all neighboring data points within 10 (DEFAULT) euclidean distance units from the original geometry and calculates the median of all target values.
#' @return DataFrame with UTM coordinates and moving window filtered (Median) values.
#'
#' @export

mvaLoop <- function(data, radius = 5){
  
  input <- data
  
  if (class(data)[1] == "sf"){
    data.sf <- data
    coords <- st_coordinates(data)
    data$geometry <- NULL
    data <- data.frame(coords, data)
    #data <- Filter(is.numeric, data.df)
  }  
  
  if (class(data)[1] == "SpatialPointsDataFrame"){
    data.sp <- data
    coords <- coordinates(data)
    nlay  <- length(names(data))
    df <- as.data.frame(data)
    data <- data.frame(coords, df[1:nlay])
    names(data)[1:2] <- c("x", "y")
  }  
  
  colnames(data)[1:2]<- c("Easting","Northing")
  #data <- Filter(is.numeric, data)
  data$ID <- 1:nrow(data)
  ref.points <- data
  
  # Create empty data frame  
  data <- dplyr::select(data, Easting, Northing, ID, everything())
  ref.points <- dplyr::select(ref.points, Easting, Northing, ID, everything())

    range.points <- data.frame(
    Point.ID = integer(),
    Easting=numeric(),
    Northing=numeric(),
    dist.to.point=numeric(),
    ref.ID=integer()
  )
  
  #i <- 1  
  for (i in 1:nrow(ref.points)){
    point.dist <- data
    squared.utm.diff <- (data[,c("Easting","Northing")]-data.frame(x = rep(ref.points[i,"Easting"],nrow(data)), y= rep(ref.points[i,"Northing"],nrow(data))))^2
    dist <- sqrt(rowSums(squared.utm.diff,1))
    point.dist$dist.to.point <- round(dist,2)
    point.dist$ref.ID <- ref.points[i,3]
    
    range.p <- dplyr::filter(point.dist, dist < radius)
    range.points <- rbind(range.points, range.p)
  }  
  #colnames(range.points)[ncol(range.points)] <- colnames(ref.points)[3]
  #result <- range.points
  
  mva.join <- dplyr::inner_join(range.points[,c("Easting", "Northing", "ID", "ref.ID")], ref.points[,c(-1,-2)], by = c("ref.ID" = "ID"))
  
  # Select only numeric columns 
  mva.numeric <- mva.join[,sapply(mva.join, is.numeric)]
  mva.points <- mva.numeric[,c(1:3)]
  mva.numeric <- mva.numeric[,c(-1,-2,-4)] 
  #head(mva.numeric)
  
  mva.median <- 
    mva.numeric %>% 
    dplyr::group_by(ID) %>% 
    dplyr::summarise_all(list(Med = median), na.rm = T)
  arrange(mva.median, ID)
  names(mva.median) <- names(mva.numeric)
  mva.median <- dplyr::inner_join(x = mva.median, y = data[,c("Easting", "Northing", "ID")], by = "ID")
  result <- dplyr::select(mva.median, Easting, Northing, ID, everything())
  
  if (class(input)[1] == "sf"){
     results.sf <- sf::st_as_sf(x = result, coords = c("Easting", "Northing"), crs = st_crs(data.sf))
     return(results.sf)
  } else if (class(input)[1] == "SpatialPointsDataFrame") {
     result.sp <- result
     coordinates(result.sp) <- ~Easting+Northing
     proj4string(result.sp) <- proj4string(data.sp)
     return(result.sp)
  } else {
     return(result) 
  }
}





