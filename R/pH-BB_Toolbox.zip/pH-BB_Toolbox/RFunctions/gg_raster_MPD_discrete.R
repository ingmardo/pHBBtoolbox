require(patchwork)
#require(ggsn)
require(ggplot2)
require(raster)

#rev(c("#806000","#BF8F00","#FFC000","#FFD966","#FFE699","#E2EFDA","#A9D08E","#70AD47","#548235","#375623"))
color_MPD <- c("#375623", "#70AD47", "#A9D08E", "grey", "#FFE699", "#FFC000", "#BF8F00", "#806000")

gg_raster_MPD_discrete <- function(data, sub = "", tit = "", cap = "Data source: Geophilus GmbH; Projektion: UTM ETRS89 33N"){
  
  df <- raster::as.data.frame(data, xy = TRUE)
  df <- na.omit(df)
  colnames(df) <- c("x", "y", "MPD")
  
  df$brks <- cut(df$MPD,
                 breaks = c(0, 0.00125, 0.00281, 0.00630, 0.01416, 0.03179, 0.07139, 0.16031, 0.35500),
                 labels=c("0 - 0.00125", 
                          "0.00125 - 0.00281", 
                          "0.00281 - 0.00630",
                          "0.00630 - 0.01416", 
                          "0.01416 - 0.03179", 
                          "0.03179 - 0.07139",
                          "0.07139 - 0.16031",
                          "0.16031 - 0.35500"))
  

  ## MPD ----
  mpd_map <-
    ggplot()+
    geom_raster(aes(x=x, y=y, fill=brks), alpha=1, data = df)+
    coord_equal()+
    scale_fill_manual(values = color_MPD, drop=FALSE)+
    labs(title = tit,
         subtitle = sub,
         caption = cap,
         fill= "MPD",
         x="Easting [m]",
         y="Norhing [m]")+
    theme_bw()
  return(mpd_map)
}

  