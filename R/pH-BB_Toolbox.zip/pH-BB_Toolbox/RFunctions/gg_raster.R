
gg_raster <- function(data, tit=" ", sub= " ", name= " ", cap= " "){
  df <- raster::as.data.frame(data, xy = TRUE)
  df <- na.omit(df)
  colnames(df)[3] <- names(data)
  map <-
    ggplot()+
    geom_raster(aes_string(x = "x", y = "y", fill = names(data)), alpha=1, data = df)+
    coord_equal()+
    scale_fill_gradientn(colours = c("#7E1900", "#C1A53A", "#D1ECC9", "#479BC5", "#1A3399"))+
    labs(title = tit,
         subtitle = sub,
         caption = cap,
         fill= paste(name),
         x="Easting [m]",
         y="Norhing [m]")+
    theme_bw()
  return(map)
}
