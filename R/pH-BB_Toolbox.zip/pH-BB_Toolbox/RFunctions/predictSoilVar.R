library(dplyr)
library(caret)
library(sf)       
library(raster)  
library(sp)       
library(data.table)
require(soiltexture)

# Helper function to extract Model fomula ----
get_model_formula <- function(id, object, outcome){
  models <- summary(object)$which[id,-1]
  predictors <- names(which(models == TRUE))
  predictors <- paste(predictors, collapse = "+")
  as.formula(paste0(outcome, "~", predictors))
}

# Performance Indices----

# MSE 
MSE <- function(obs, pred){
  mse.val <- round(mean((pred - obs)**2), digits = 2)
  return(mse.val)
}

# NSE aka AVE (Amount variance explained based on 1:1 Line)
NSE <- function(obs, pred){
  nse <- round(1-(sum((pred-obs)**2)/(sum((obs -mean(obs))**2))),2)
  return(nse)
}

# RMSE
RMSE <- function(obs, pred){
  return(round(sqrt(mean((pred-obs)**2)), digits = 3))
}

# MAE
MAE <- function(obs, pred){
  return(round(mean(abs(pred-obs)), digits = 3))
}

# Predict soil variable ---- 
predictSoilVar <- function(lab, covars, response, crs = 25833){
  
  # convert to SpatialGridDataFrame
  sensor.sp <- as(covars, "SpatialGridDataFrame")
  
  # further convert to data.frame
  sensor.df <- as(sensor.sp, Class = "data.frame")
  
  ## (Near-)zero variance analysis ----
  nzv <- caret::nearZeroVar(sensor.df, saveMetrics = TRUE)
  
  # drop nzv layers ----
  sensor.df <- sensor.df[,!nzv[,4]]
  
  ## Removing incomplete data pixels ----
  
  # re-order; names of coordinate columns are "s1","s2"
  covar.df <- dplyr::select(sensor.df,s1, s2, everything())
  
  # Exclude pixels that do not have complete covariate data
  covar.df <- covar.df[complete.cases(covar.df[,3:ncol(covar.df)]),]
  message(paste0(nrow(sensor.df) - nrow(covar.df), " pixels removed that do not have complete covariate data"))
  
  # Make RasterStack
  #head(covar.df)
  covar.st <- covar.df
  gridded(covar.st) <- ~ s1 + s2
  proj4string(covar.st) <- CRS(paste0("+init=epsg:",25833))
  covar.st <- stack(covar.st)
  
  # Create Regression Matrix ----
  bp.sp <- lab[, c("x", "y",response)]
  coordinates(bp.sp) <- ~x + y
  proj4string(bp.sp) <- CRS(paste0("+init=epsg:",25833))
  cv.extr <- raster::extract(covar.st, bp.sp)
  rm <- cbind(bp.sp@data, bp.sp@coords, cv.extr)
  rm <- rm[complete.cases(rm[,c(1,4:ncol(rm))]),]
  
  #  Multivariate Statistical Models ----
  
  # Response Variable
  d <- rm[,1]
  #nrow(rm)
  
  # Covariates  
  covar <- rm[,4:ncol(rm)]
  covar <- data.frame(covar)
  names(covar) <- names(rm)[4:ncol(rm)]
  
  # Prepare-Cross-Validation: (1) LOOCV (for n < 20) else (2) Repeated-K-Fold-CV ----
  if (nrow(rm) < 20) {
    cv.control <- trainControl(method="LOOCV", 
                               number = 1,
                               selectionFunction = "tolerance")
  } else {
    myfolds <- createMultiFolds(rm[,1], k = 4, times = 100)
    cv.control <- trainControl("repeatedcv", 
                               index = myfolds, 
                               selectionFunction = "tolerance", 
                               savePredictions = T)
  }
  
  # Scatterplot of response variavle vs. covars  
  responseUntidy <- tidyr::gather(rm, key = "Variable",
                                  value = "Value", 4:ncol(rm))
  gg.splom <-
    ggplot(responseUntidy, aes_string("Value", response)) +
    facet_wrap(~ Variable, scale = "free_x") +
    geom_point() +
    geom_smooth() +
    geom_smooth(method = "lm", col = "red") +
    theme_bw()
  
  # -----------------------------------------------------------------------------  
  # # Predict soil maps for SOM and pH ----
  # -----------------------------------------------------------------------------
  
  #' ## Train MLR Model ----
  nvar <- ncol(covar.df)-2
  mlr.L <- list()
  
  # If only one co-variable exists just fit a linear model ---- 
  if (nvar <=1) {
    
    mlr <- caret::train(as.formula(paste0(response, "~", names(covar))),
                           data = rm[,c(1,4:ncol(rm))],
                           method = "lm",
                           trControl = cv.control)
    
    # Save LM model results ----
    mlr.L$mlrTrain <- mlr
    mlr.L$bestVars <- as.formula(paste0(response, "~", names(covar)))
    
    # Save MLR valdiation results ----
    mlr.cv.df <- mlr$results
    mlr.cv.df <- mlr.cv.df[,2:4]
    
    # Predict MLR Map ----
    mlr.df <- predict(object = mlr, newdata = covar.df) 
    rp.mlr.df <- data.frame(covar.df[,1:2], y = round(mlr.df,2))
    names(rp.mlr.df)[3] <- response
    mlr.r <- rasterFromXYZ(rp.mlr.df)
    proj4string(mlr.r) <- CRS(paste0("+init=epsg:",crs))
    #plot(mlr.r)
    
    if (mlr$control$method == "LOOCV"){
      mlr$pred$Resample <- 1
    }
    
    # Calculate NSE for CV results ---- 
    mlr.NSE <- 
      mlr$pred %>% 
      group_by(Resample) %>% 
      summarise(MAE = MAE(obs, pred),
                NSE = NSE(obs, pred),
                RMSE = RMSE(obs, pred)) %>% 
      as.data.frame()
    mlr.cv.df$NSE <- mlr.NSE[as.numeric(mlr$bestTune),3]
    mlr.L$mlrCV <- round(mlr.cv.df,2)
    mlr.L$mlrMap <- mlr.r
    
    # Save Output results ----
    results <- list()
    results$LM <- mlr.L
    results$SPLOM <- gg.splom
    results$regressionMatrix <- rm
    mlr.cv.df$Model <- "LM" 
    mlr.cv.df$Response <- response 
    mlr.cv.df$CVInfo <- cv.control$method
    mlr.cv.df$N <- nrow(rm)
    results$CompareModels <- mlr.cv.df
    return(results)
  } else {
    
    if (nvar >= 8) {
      nvar <- 8
    } 
    
    mlr <- caret::train(x = covar, y = d,
                        method = "leapForward", 
                        tuneGrid = data.frame(nvmax = 1:nvar),
                        trControl = cv.control)
    #summary(mlr$finalModel)
    #mlr$control$method
    
    mlr.fit <- caret::train(get_model_formula(as.numeric(mlr$bestTune), mlr$finalModel, response),
                            data = rm[,c(1,4:ncol(rm))],
                            method = "lm",
                            trControl = cv.control)
    
    # Save MLR model results ----
    mlr.L$mlrTrain <- mlr
    mlr.L$bestVars <- as.character(get_model_formula(as.numeric(mlr$bestTune), mlr$finalModel, response))[3]
    
    # Save MLR valdiation results ----
    mlr.cv.df <-mlr$results[as.numeric(mlr$bestTune),]
    mlr.cv.df <- mlr.cv.df[,2:4]
    
    # Predict MLR Map ----
    mlr.df <- predict(object = mlr.fit, newdata = covar.df) 
    rp.mlr.df <- data.frame(covar.df[,1:2], y = round(mlr.df,2))
    names(rp.mlr.df)[3] <- response
    mlr.r <- rasterFromXYZ(rp.mlr.df)
    proj4string(mlr.r) <- CRS(paste0("+init=epsg:",crs))
    #plot(mlr.r)
    
    if (mlr$control$method == "LOOCV"){
      mlr$pred$Resample <- 1
    }
    
    # Calculate NSE for CV results ---- 
    mlr.NSE <- 
      mlr$pred %>% 
      group_by(nvmax,Resample) %>% 
      summarise(MAE = MAE(obs, pred),
                NSE = NSE(obs, pred),
                RMSE = RMSE(obs, pred)) %>% 
      group_by(nvmax) %>%
      summarise(MAE = mean(MAE),
                NSE = mean(NSE),
                RMSE = mean(RMSE)) %>% 
      as.data.frame()
    mlr.cv.df$NSE <- mlr.NSE[as.numeric(mlr$bestTune),3]
    mlr.L$mlrCV <- round(mlr.cv.df,2)
    mlr.L$mlrMap <- mlr.r
    
    # -----------------------------------------------------------------------------
    # ## Train Random Forest ----
    # -----------------------------------------------------------------------------
    rf.L <- list()
    mtry <- floor(ncol(covar)/3)
    
    rf <- caret::train(x = covar, y = d,
                       trControl = cv.control,
                       method = "rf", 
                       metric = "MAE", 
                       #preProcess = "scale", 
                       trace = FALSE,
                       #do.trace=25,
                       tuneGrid = expand.grid(mtry = 1:3),
                       maxit = 1000)
    #rf
    
    
    # Save rf results ----
    rf.L$rfTrain <- rf
    
    # RF - Validation results final Model ----
    rf.cv.df <-rf$results[as.numeric(rf$bestTune),]
    rf.cv.df <- rf.cv.df[,2:4]
    
    # Predict RF Map ----
    rp.rf <- predict(rf, covar.df) 
    rp.rf.df <- data.frame(covar.df[,1:2], y = round(rp.rf,2))
    names(rp.rf.df)[3] <- response
    rf.r <- rasterFromXYZ(rp.rf.df)
    proj4string(rf.r) <- CRS(paste0("+init=epsg:",crs))
    #plot(rf.r)
    
    if (rf$control$method == "LOOCV"){
      rf$pred$Resample <- 1
    }
    
    # Calculate NSE for CV 
    rf.NSE <- 
      rf$pred %>% 
      group_by(mtry,Resample) %>% 
      summarise(MAE = MAE(obs, pred),
                NSE = NSE(obs, pred),
                RMSE = RMSE(obs, pred)) %>% 
      group_by(mtry) %>%
      summarise(MAE = mean(MAE),
                NSE = mean(NSE),
                RMSE = mean(RMSE)) %>% 
      as.data.frame()
    rf.cv.df$NSE <- rf.NSE[as.numeric(rf$bestTune),3]
    rf.L$rfCV <- round(rf.cv.df,2)
    rf.L$rfMap <- rf.r
    
    # -----------------------------------------------------------------------------
    # ## Train PLSR model ----
    # -----------------------------------------------------------------------------
    plsr.L <- list()
    
    # pre-process data for PLSR
    trans <- caret::preProcess(covar.df[,c(-1,-2)], method=c("center", "scale"))
    covar.trans <- predict(trans, covar)
    covar.df.trans <- predict(trans, covar.df[,c(-1,-2)])
    
    plsr <- train(x = covar.trans, y = d, 
                  trControl = cv.control,
                  method = "pls",
                  #preProc = c("center","scale"),
                  tuneLength = 5)
    #plsr$finalModel
    plsr.L$plsrTrain <- plsr
    
    # PLSR - Valdiation results final Model ----
    plsr.cv.df <- plsr$results[as.numeric(plsr$bestTune),]
    plsr.cv.df <- plsr.cv.df[,2:4]
    
    # Create PLSR-Map  ----
    rp.plsr <- predict(plsr, covar.df.trans) 
    rp.plsr.df <- data.frame(covar.df[,1:2], pH = round(rp.plsr,2))
    names(rp.plsr.df)[3] <- response
    plsr.r <- rasterFromXYZ(rp.plsr.df)
    proj4string(plsr.r) <- CRS(paste0("+init=epsg:",crs))
    #plot(plsr.r)
    
    if (plsr$control$method == "LOOCV"){
      plsr$pred$Resample <- 1
    }
    
    # Calculate NSE for PLSR-CV results ---- 
    plsr.NSE <- 
      plsr$pred %>% 
      group_by(ncomp, Resample) %>% 
      summarise(MAE = MAE(obs, pred),
                NSE = NSE(obs, pred),
                RMSE = RMSE(obs, pred)) %>% 
      group_by(ncomp) %>%
      summarise(MAE = mean(MAE),
                NSE = mean(NSE),
                RMSE = mean(RMSE)) %>% 
      as.data.frame()
    plsr.cv.df$NSE <- plsr.NSE[as.numeric(plsr$bestTune),3]
    plsr.L$plsrCV <- round(plsr.cv.df,2)
    plsr.L$plsrMap <- plsr.r
    
    # -----------------------------------------------------------------------------
    #  Compare Models ----
    # -----------------------------------------------------------------------------
    cv.models <- rbind(mlr.L$mlrCV, plsr.L$plsrCV, rf.L$rfCV)
    cv.models$Model <- c("MLR", "PLSR", "RF") 
    cv.models$Response <- response 
    cv.models$CVInfo <- cv.control$method
    cv.models$N <- nrow(rm)
    
    # Save Output results ----
    results <- list()
    results$MLR <- mlr.L
    results$PLSR <- plsr.L
    results$RF <- rf.L
    results$CompareModels <- cv.models
    results$SPLOM <- gg.splom
    results$regressionMatrix <- rm
    names(results)[1:3] <- c("MLR", "PLSR", "RF")
    return(results)
  }
}

# --------
# End
# --------