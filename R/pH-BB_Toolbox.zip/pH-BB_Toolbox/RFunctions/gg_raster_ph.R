
# pH-Color-Scales ----
color_ph1 <- c("#FF2900","#FF4A08","#FF7310","#FF9C18","#FFDE20",
              "#E6EE31","#9CBD41","#5A835A","#39526A","#29416A",
              "#183173","#08187B")

color_ph2 <- c("#f42427", "#f24f45", "#f86d35", "#f5a525", "#ffc051",
               "#f2f43e", "#e0ea2b", "#9ec858", "#4cc160", "#1cb4ac",
               "#168fbe", "#31469e", "#383477")

color_ph3 <- rev(c("#191970", "#40E0D0", "#ADD8E6", "#BEBEBE", "#F0E68C", "#FFA500", "#FF0000", "#B03060"))

limits_ph <-  c(3,9)
breaks_ph <-  c(3, 4, 5, 6, 7, 8, 9)

gg_raster_ph <- function(data, sub = "", name = "pH"){
  df <- raster::as.data.frame(data, xy = TRUE)
  df <- na.omit(df)
  colnames(df)[3] <- name
  pH_map <-
    ggplot()+
    geom_raster(aes_string(x = "x", y = "y", fill = name), alpha=1, data = df)+
    coord_equal()+
    scale_fill_gradientn(limits = c(3,9), breaks = c(3, 4, 5, 6, 7, 8, 9), colours = color_ph1)+
    labs(title = "pH",
         subtitle = sub,
         caption = "Data source: ph-BB; Projektion: UTM ETRS89 33N",
         fill= paste(name),
         x="Easting [m]",
         y="Norhing [m]")+
    theme_bw()
  return(pH_map)
}
