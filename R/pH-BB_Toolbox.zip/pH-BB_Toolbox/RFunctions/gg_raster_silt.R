require(ggplot2)
require(raster)

gg_raster_silt <- function(data, tit = "Schluff" ,sub = ""){
  df <- raster::as.data.frame(data, xy = TRUE)
  df <- na.omit(df)
  colnames(df) <- c("x", "y", "Schluff")
  
  schluff_map <- 
    ggplot()+
    geom_raster(aes(x=x, y=y, fill=Schluff), data = df, alpha = 1)+
    #scale_fill_distiller(palette = "YlOrBr", breaks = c(0,20,40,60,80,100), limits = c(0,100), direction = 1) +
    scale_fill_gradientn(colours = c("#f8f6cf", "#fbf8aa", "#f5ce66", "#ec8450", "#d55341", "#985f56", "#5d5e5e",
                                     "#2f3030"))+
    coord_equal()+
    labs(title = tit,
         subtitle = sub,
         fill= paste("[%]"),
         x="Easting [m]",
         y="Norhing [m]")+
    theme_bw()
    
  return(schluff_map)
}  
