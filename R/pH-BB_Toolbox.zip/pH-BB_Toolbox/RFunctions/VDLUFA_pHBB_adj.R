

VDLUFA_pHBB_adj <- function(cao, liv, year, mask){
  
  # Transform to data frame 
  cao <- cao[[c("SOM", "pH", "Clay", "Soil", "LSL", "CaO")]]
  names(cao) <- c("Humus", "pH", "Ton", "VDLUFA_BG", "pH_Klasse_num", "CaO")
  soil_stack_df <- cbind(coordinates(cao), as.data.frame(cao))
  
  # Define ID for every entry
  soil_stack_df$ID <- 1:length(soil_stack_df$CaO)
  soil_stack_df$Humus <- round(soil_stack_df$Humus,1)
  
  # Define Humus classes according to VDLUFA scheme
  soil_stack_df$Humus_Klasse <- "NA"
  soil_stack_df$Humus_Klasse[!is.na(soil_stack_df$Humus) & soil_stack_df$Humus <= 4] <- "A"
  soil_stack_df$Humus_Klasse[!is.na(soil_stack_df$Humus) & soil_stack_df$Humus > 4 & soil_stack_df$Humus <= 8] <- "B"
  soil_stack_df$Humus_Klasse[!is.na(soil_stack_df$Humus) & soil_stack_df$Humus > 8 & soil_stack_df$Humus <= 15] <- "C"
  soil_stack_df$Humus_Klasse[!is.na(soil_stack_df$Humus) & soil_stack_df$Humus > 15] <- "D"
  
  # Define pH classes according to VDLUFA scheme
  soil_stack_df$pH_Klasse[which(soil_stack_df$pH_Klasse_num == 1)] <- "A"
  soil_stack_df$pH_Klasse[which(soil_stack_df$pH_Klasse_num == 2)] <- "B"
  soil_stack_df$pH_Klasse[which(soil_stack_df$pH_Klasse_num == 3)] <- "C"
  soil_stack_df$pH_Klasse[which(soil_stack_df$pH_Klasse_num == 4)] <- "D"
  soil_stack_df$pH_Klasse[which(soil_stack_df$pH_Klasse_num == 5)] <- "E"
  
  # Round continuous values to appropriate numbers
  soil_stack_df$Ton <- round(soil_stack_df$Ton, 1)
  soil_stack_df$pH <- round(soil_stack_df$pH, 1)
  soil_stack_df$CaO <- round(soil_stack_df$CaO, 1)
  
  # subset data set without NAs
  soil_stack_df.rmna <- na.omit(soil_stack_df)  
  rownames(soil_stack_df.rmna) <- 1:nrow(soil_stack_df.rmna)
  #head(soil_stack_df.rmna)
  
  # create list and attach all data and data without NAs 
  VDLUFA_results <- list()
  VDLUFA_results[[1]] <- soil_stack_df.rmna
  VDLUFA_results[[2]] <- soil_stack_df
  names(VDLUFA_results) <- c("CaO_Na_Omit", "CaO_all")
  #str(VDLUFA_results)
  
  # Calculate surcharge/discount factor (ZF)  ----
  
  # ZF of liming interval 
  ZF.LIV <- (liv-4)/4
  
  # Year of soil lab analysis
  date <- (as.Date(Sys.time(), "YYYY", tz = "GMT"))
  date <- as.numeric(format(date, format = "%Y"))
  ZF.boden <- (date-year)/4
  ZF <- ZF.LIV+ZF.boden
  ZF
  
  if (ZF == 0) {
    cao.fin <- cao
    cao.fin$CaO <- cao.fin$CaO*100
    cao.fin$CaO <- as.integer(cao.fin$CaO)
    names(cao.fin) <- c("SOM", "pH", "Clay", "Soil", "LSL", "CaO")
    #names(cao.fin)
    cao.fin <- cao.fin[[c(6,5,4,2,1,3)]]
    #names(cao.fin)
    cao.fin.df <- as.data.frame(cao.fin, xy=TRUE)
    som_level_df <- VDLUFA_FW_df(soil = cao.fin.df[,c("Soil", "SOM", "pH")])
    som_level_fac <- factor(som_level_df$CaO_all$SOM_Lstr, levels = c("A", "B", "C", "D", "E"))
    som_level_num <- as.numeric(som_level_fac)
    cao.fin$SOML <- som_level_num
    cao.fin <- cao.fin[[c(1,2,7,3,4,5,6)]]
    names(cao.fin)
    
  }
  
  if (ZF < 0){
    cao.fin <- cao
    AF <- 1-abs(ZF)
    cao.fin$CaO <- cao.fin$CaO*AF*100
    cao.fin$CaO <- as.integer(cao.fin$CaO)
    names(cao.fin) <- c("SOM", "pH", "Clay", "Soil", "LSL", "CaO")
    cao.fin <- cao.fin[[c(6,5,4,2,1,3)]]
    cao.fin.df <- as.data.frame(cao.fin, xy=TRUE)
    som_level_df <- VDLUFA_FW_df(soil = cao.fin.df[,c("Soil", "SOM", "pH")])
    som_level_fac <- factor(som_level_df$CaO_all$SOM_Lstr, levels = c("A", "B", "C", "D", "E"))
    som_level_num <- as.numeric(som_level_fac)
    cao.fin$SOML <- som_level_num
    cao.fin <- cao.fin[[c(1,2,7,3,4,5,6)]]
    #names(cao.fin) <- c("CaO", "LSL", "SOML", "Soil", "pH", "SOM", "Clay")
    
  } else {
    
    # LUT table to adjust CaO amount (deduction/surcharge) for level C
    lut_adjust <- data.frame(
      VDLUFA_BG = c(1, 1, 1, 1, 
                    2, 2, 2, 2, 
                    3, 3, 3, 3, 
                    4, 4, 4, 4, 
                    5, 5, 5, 5, 6),
      Humus_Klasse = c("A", "B", "C", "D", 
                       "A", "B", "C", "D", 
                       "A", "B", "C", "D", 
                       "A", "B", "C", "D", 
                       "A", "B", "C","D", "E"),
      pH_Klasse = c("C", "C", "C", "C", 
                    "C", "C", "C", "C", 
                    "C", "C", "C", "C", 
                    "C", "C", "C", "C", 
                    "C", "C", "C", "C", "C"),
      pH_Mean = c(5.6, 5.2, 4.9, 4.5, 
                  6.05, 5.65, 5.25, 4.85, 
                  6.4, 5.9, 5.5, 5.1, 
                  6.65, 6.15, 5.75, 5.35, 
                  6.8, 6.3, 5.9,  5.5,  4.3)
    )
    # head(lut_adjust)
    cao.add <- VDLUFA_results$CaO_all
    head(cao.add)
    cao.add$pH_Klasse[which(cao.add$pH_Klasse == "A")] <- "C"
    cao.add$pH_Klasse[which(cao.add$pH_Klasse == "B")] <- "C"
    
    cao.add$pH[which(cao.add$pH_Klasse == "C" & cao.add$Humus_Klasse == "A" & cao.add$VDLUFA_BG == 1)] <-
      lut_adjust$pH_Mean[which(lut_adjust$pH_Klasse == "C" & lut_adjust$Humus_Klasse == "A" & lut_adjust$VDLUFA_BG == 1)]
    
    cao.add$pH[which(cao.add$pH_Klasse == "C" & cao.add$Humus_Klasse == "A" & cao.add$VDLUFA_BG == 2)] <-
      lut_adjust$pH_Mean[which(lut_adjust$pH_Klasse == "C" & lut_adjust$Humus_Klasse == "A" & lut_adjust$VDLUFA_BG == 2)]
    
    cao.add$pH[which(cao.add$pH_Klasse == "C" & cao.add$Humus_Klasse == "A" & cao.add$VDLUFA_BG == 3)] <-
      lut_adjust$pH_Mean[which(lut_adjust$pH_Klasse == "C" & lut_adjust$Humus_Klasse == "A" & lut_adjust$VDLUFA_BG == 3)]
    
    cao.add$pH[which(cao.add$pH_Klasse == "C" & cao.add$Humus_Klasse == "A" & cao.add$VDLUFA_BG == 4)] <-
      lut_adjust$pH_Mean[which(lut_adjust$pH_Klasse == "C" & lut_adjust$Humus_Klasse == "A" & lut_adjust$VDLUFA_BG == 4)]
    
    cao.add$pH[which(cao.add$pH_Klasse == "C" & cao.add$Humus_Klasse == "A" & cao.add$VDLUFA_BG == 5)] <-
      lut_adjust$pH_Mean[which(lut_adjust$pH_Klasse == "C" & lut_adjust$Humus_Klasse == "A" & lut_adjust$VDLUFA_BG == 5)]
    
    cao.add$pH[which(cao.add$pH_Klasse == "C" & cao.add$Humus_Klasse == "B" & cao.add$VDLUFA_BG == 1)] <-
      lut_adjust$pH_Mean[which(lut_adjust$pH_Klasse == "C" & lut_adjust$Humus_Klasse == "B" & lut_adjust$VDLUFA_BG == 1)]
    
    cao.add$pH[which(cao.add$pH_Klasse == "C" & cao.add$Humus_Klasse == "B" & cao.add$VDLUFA_BG == 2)] <-
      lut_adjust$pH_Mean[which(lut_adjust$pH_Klasse == "C" & lut_adjust$Humus_Klasse == "B" & lut_adjust$VDLUFA_BG == 2)]
    
    cao.add$pH[which(cao.add$pH_Klasse == "C" & cao.add$Humus_Klasse == "B" & cao.add$VDLUFA_BG == 3)] <-
      lut_adjust$pH_Mean[which(lut_adjust$pH_Klasse == "C" & lut_adjust$Humus_Klasse == "B" & lut_adjust$VDLUFA_BG == 3)]
    
    cao.add$pH[which(cao.add$pH_Klasse == "C" & cao.add$Humus_Klasse == "B" & cao.add$VDLUFA_BG == 4)] <-
      lut_adjust$pH_Mean[which(lut_adjust$pH_Klasse == "C" & lut_adjust$Humus_Klasse == "B" & lut_adjust$VDLUFA_BG == 4)]
    
    cao.add$pH[which(cao.add$pH_Klasse == "C" & cao.add$Humus_Klasse == "B" & cao.add$VDLUFA_BG == 5)] <-
      lut_adjust$pH_Mean[which(lut_adjust$pH_Klasse == "C" & lut_adjust$Humus_Klasse == "B" & lut_adjust$VDLUFA_BG == 5)]
    
    cao.add$pH[which(cao.add$pH_Klasse == "C" & cao.add$Humus_Klasse == "C" & cao.add$VDLUFA_BG == 1)] <-
      lut_adjust$pH_Mean[which(lut_adjust$pH_Klasse == "C" & lut_adjust$Humus_Klasse == "C" & lut_adjust$VDLUFA_BG == 1)]
    
    cao.add$pH[which(cao.add$pH_Klasse == "C" & cao.add$Humus_Klasse == "C" & cao.add$VDLUFA_BG == 2)] <-
      lut_adjust$pH_Mean[which(lut_adjust$pH_Klasse == "C" & lut_adjust$Humus_Klasse == "C" & lut_adjust$VDLUFA_BG == 2)]
    
    cao.add$pH[which(cao.add$pH_Klasse == "C" & cao.add$Humus_Klasse == "C" & cao.add$VDLUFA_BG == 3)] <-
      lut_adjust$pH_Mean[which(lut_adjust$pH_Klasse == "C" & lut_adjust$Humus_Klasse == "C" & lut_adjust$VDLUFA_BG == 3)]
    
    cao.add$pH[which(cao.add$pH_Klasse == "C" & cao.add$Humus_Klasse == "C" & cao.add$VDLUFA_BG == 4)] <-
      lut_adjust$pH_Mean[which(lut_adjust$pH_Klasse == "C" & lut_adjust$Humus_Klasse == "C" & lut_adjust$VDLUFA_BG == 4)]
    
    cao.add$pH[which(cao.add$pH_Klasse == "C" & cao.add$Humus_Klasse == "C" & cao.add$VDLUFA_BG == 5)] <-
      lut_adjust$pH_Mean[which(lut_adjust$pH_Klasse == "C" & lut_adjust$Humus_Klasse == "C" & lut_adjust$VDLUFA_BG == 5)]
    
    cao.add$pH[which(cao.add$pH_Klasse == "C" & cao.add$Humus_Klasse == "D" & cao.add$VDLUFA_BG == 1)] <-
      lut_adjust$pH_Mean[which(lut_adjust$pH_Klasse == "C" & lut_adjust$Humus_Klasse == "D" & lut_adjust$VDLUFA_BG == 1)]
    
    cao.add$pH[which(cao.add$pH_Klasse == "C" & cao.add$Humus_Klasse == "D" & cao.add$VDLUFA_BG == 2)] <-
      lut_adjust$pH_Mean[which(lut_adjust$pH_Klasse == "C" & lut_adjust$Humus_Klasse == "D" & lut_adjust$VDLUFA_BG == 2)]
    
    cao.add$pH[which(cao.add$pH_Klasse == "C" & cao.add$Humus_Klasse == "D" & cao.add$VDLUFA_BG == 3)] <-
      lut_adjust$pH_Mean[which(lut_adjust$pH_Klasse == "C" & lut_adjust$Humus_Klasse == "D" & lut_adjust$VDLUFA_BG == 3)]
    
    cao.add$pH[which(cao.add$pH_Klasse == "C" & cao.add$Humus_Klasse == "D" & cao.add$VDLUFA_BG == 4)] <-
      lut_adjust$pH_Mean[which(lut_adjust$pH_Klasse == "C" & lut_adjust$Humus_Klasse == "D" & lut_adjust$VDLUFA_BG == 4)]
    
    cao.add$pH[which(cao.add$pH_Klasse == "C" & cao.add$Humus_Klasse == "D" & cao.add$VDLUFA_BG == 5)] <-
      lut_adjust$pH_Mean[which(lut_adjust$pH_Klasse == "C" & lut_adjust$Humus_Klasse == "D" & lut_adjust$VDLUFA_BG == 5)]
    
    cao.add$SOML <- as.numeric(factor(cao.add$Humus_Klasse, levels = c("A", "B", "C", "D", "E")))
    #names(cao.add)
    ras.stk.new <- rasterFromXYZ(cao.add[c(1:6,12)])
    proj4string(ras.stk.new) <- CRS(paste0("+init=epsg:25833"))
    
    # Recalculate ----
    cao.new <- VDLUFA_phBB_r(soil = ras.stk.new$VDLUFA_BG, 
                                som = ras.stk.new$Humus, 
                                ph = ras.stk.new$pH,
                                clay = ras.stk.new$Ton,
                                mask)
    cao.new$zuschlag <- cao.new$CaO*ZF
    cao.fin <- cao
    cao.fin$CaO <- cao$CaO + cao.new$zuschlag
    
    cao.fin$SOML <- ras.stk.new$SOML
    cao.fin$CaO <- round(cao.fin$CaO * 100,0) 
    cao.fin$CaO <- as.integer(cao.fin$CaO)
    cao.fin$Humus <- round(cao.fin$Humus, 1)
    
    # Change layer order 
    cao.fin <- cao.fin[[c(6,5,7,4,2,1,3)]]
    names(cao.fin)
    
    
    names(cao.fin) <- c("CaO", "LSL", "SOML", "Soil", "pH", "SOM", "Clay")
  }
  
  names(cao.fin)
  #names(cao.fin) <- c("CaO", "LSL", "SOML", "Soil", "pH", "SOM", "Clay")
  #message(paste("Der ZF betraegt:", ZF))
  
  date2 <- (as.Date(Sys.time(), "YYYY", tz = "GMT"))
  date2 <- as.numeric(format(date2, format = "%Y"))
  
  # Adjustment of CaO amounts and review of recommended maximum amounts
  cao.adj <- cao_limits_check(cao = cao.fin[[1:6]], LIV = 4, pHYear = date2, zf = ZF)
  return(cao.adj)
}
  
cao_limits_check <- function (cao, LIV = 4, pHYear, zf) {
  pix.res <- raster::res(cao)
  pix.area <- pix.res[1] * pix.res[2]
  if (missing(cao)) 
    stop("Argument 'cao' must be of type RasterStack as obtainded with the VDLUFA_FW_r function.")
  if (missing(pHYear)) 
    stop("Argument 'pHYear' must be a number (Integer) e.g. 2021 representing the year where the pH-data were mapped.")
  ZF.LIV <- (LIV - 4)/4
  date <- (as.Date(Sys.time(), "YYYY", tz = "GMT"))
  date <- as.numeric(format(date, format = "%Y"))
  ZF.boden <- (date - pHYear)/4
  ZF <- ZF.LIV + ZF.boden
  LUT_C_Cao <- structure(list(Soil = c(1L, 1L, 1L, 1L, 2L, 
                                       2L, 2L, 2L, 3L, 3L, 3L, 3L, 4L, 4L, 4L, 4L, 5L, 5L, 5L, 
                                       5L, 6L), 
                              LSL = c(3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 
                                      3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L, 3L), 
                              SOML = c(1L, 2L, 3L, 4L, 1L, 2L, 3L, 4L, 1L, 2L, 3L, 4L, 1L, 2L, 3L, 4L, 1L, 2L, 3L, 4L, 5L), 
                              CaO = c(6L, 5L, 4L, 3L, 10L, 9L, 8L, 4L, 14L, 12L, 10L, 5L, 17L, 15L, 13L, 6L, 20L, 18L, 16L, 7L, 0L)),
                         class = "data.frame", row.names = c(NA, -21L))
  cao.df <- as.data.frame(cao, xy = T)
  cao.df$ID <- 1:nrow(cao.df)
  cao_na_omit <- na.omit(cao.df)
  cao_na_omit$Soil <- as.integer(cao_na_omit$Soil)
  cao_na_omit$LSL <- as.integer(cao_na_omit$LSL)
  cao_na_omit$SOML <- as.integer(cao_na_omit$SOML)
  lime_surcha <- dplyr::select(cao_na_omit, ID, Soil, LSL, SOML)
  lime_surcha$LSL <- 3
  lime_surcha <- dplyr::left_join(lime_surcha, LUT_C_Cao, by = c("LSL", "Soil", "SOML"))
  lime_surcha$CaO <- lime_surcha$CaO * 100
  if (ZF < 0) {
    AF <- ZF
    lime_surcha$zuschlag <- cao_na_omit$CaO * AF
  }
  if (ZF >= 0) {
    lime_surcha$zuschlag <- lime_surcha$CaO * ZF
  }
  cao_na_omit$zuschlag <- NA
  cao_na_omit$zuschlag <- lime_surcha$zuschlag
  cao_na_omit$zuschlag[cao_na_omit$LSL == 4] <- 0
  cao_na_omit$zuschlag[cao_na_omit$LSL == 5] <- 0
  cao_na_omit$CaO_Anp <- cao_na_omit$CaO + cao_na_omit$zuschlag
  cao_limits_lut <- data.frame(Soil = 1:6, CaOLimit = c(2800, 4200, 5600, 7000, 8400, 2800))
  cao.check <- dplyr::select(cao_na_omit, ID, Soil, CaO_Anp)
  cao.check <- dplyr::left_join(cao.check, cao_limits_lut, by = c("Soil"))
  cao.check$Diff <- cao.check$CaOLimit - cao.check$CaO_Anp
  cao.check$CaOAPP1 <- cao.check$CaO_Anp
  cao.check$CaOAPP2 <- 0
  cao.check <- na.omit(cao.check)
  cao.check[cao.check$CaO_Anp >= cao.check$CaOLimit, 6] <- cao.check[cao.check$CaO_Anp >= cao.check$CaOLimit, 4]
  cao.check$CaOAPP2 <- cao.check$CaO_Anp - cao.check$CaOAPP1
  sumCaOApp1 <- round(sum(cao.check$CaOAPP1 * (pix.area/10000))/1000, 1)
  sumCaOApp2 <- round(sum(cao.check$CaOAPP2 * (pix.area/10000))/1000, 1)
  caoapp.r <- cao$CaO
  names(caoapp.r) <- "CaOAPP1"
  caoapp.r[cao.check$ID] <- cao.check$CaOAPP1
  
  if (sumCaOApp2 > 0) {
    message(paste("Es erfolgt ein Gabenteilung, da die empfohlene Hoechstmenge je Kalkung Ueberschritten wird.\nDie CaO Menge wird auf zwei Karten aufgeteilt.\nGesamtmenge CaO fuer Karte1 (CaOApp1):", 
                  sumCaOApp1, "[t]", "und fuer Karte2 (CaOApp2):", 
                  sumCaOApp2, " [t] und der ZF:", zf))
    caoapp.r$CaOAPP2 <- caoapp.r$CaOAPP1
    caoapp.r$CaOAPP2[cao.check$ID] <- cao.check$CaOAPP2
  }
  else {
    message(paste("Die auszubringende Gesamtmenge CaO (CaOApp1) betraegt:", sumCaOApp1, "[t] und der ZF:", zf))
  }
  return(caoapp.r)
}


  
