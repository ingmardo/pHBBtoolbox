library(raster)
library(pH)

# CaO-Stufenlos routine ----
VDLUFA_phBB_r <- function(soil, som , ph, clay, mask, res = c(2, 2), width = 0) {
  
  mask.r <- pH::createRaster(boundary = mask, res = res, buffer = width)
  vdl.rast <- projectRaster(soil, mask.r, method = "ngb")
  soc.rast <- projectRaster(som, mask.r, method = "bilinear")
  ph.rast <- projectRaster(ph, mask.r, method = "bilinear")
  clay.rast <- projectRaster(clay, mask.r, method = "bilinear")
  
  names(vdl.rast) <- "VDLUFA_BG"
  names(soc.rast) <- "Humus"
  names(ph.rast) <- "pH"
  names(clay.rast) <- "Ton"

  # #### raster data ####
  # ph.rast = soil.parms$pH
  # soc.rast = soil.parms$Humus
  # clay.rast = soil.parms$Ton
  # vdl.rast = soil.parms$VDLUFA_BG
  # 
  # #### create similar rasters with equal NA statuses (resampling and masking) ####
  # ph.rast = resample(ph.rast, clay.rast)
  # ph.rast = mask(ph.rast, clay.rast)
  # 
  # soc.rast = resample(soc.rast, clay.rast)
  # soc.rast = mask(soc.rast, clay.rast)
  # 
  # vdl.rast = resample(vdl.rast, clay.rast)
  # vdl.rast = mask(vdl.rast, clay.rast)
  
  ph.rast[is.na(soc.rast[])] = NA
  clay.rast[is.na(soc.rast[])] = NA
  vdl.rast[is.na(soc.rast[])] = NA
  
  soc.rast[is.na(ph.rast[])] = NA
  clay.rast[is.na(ph.rast[])] = NA
  vdl.rast[is.na(ph.rast[])] = NA
  
  ph.rast[is.na(clay.rast[])] = NA
  soc.rast[is.na(clay.rast[])] = NA
  vdl.rast[is.na(clay.rast[])] = NA
  
  ph.rast[is.na(vdl.rast[])] = NA
  soc.rast[is.na(vdl.rast[])] = NA
  clay.rast[is.na(vdl.rast[])] = NA
  
  #### change clay and SOC values that are out of threshold values (VDLUFA Rahmenschema Tabelle 8) ####
  clay.rast[clay.rast < 0] = 0.1
  clay.rast[clay.rast > 45] = 45
  
  soc.rast[soc.rast < 0] = 0.1
  soc.rast[soc.rast > 22.5] = 22.5
  
  #### create table from raster datasets without NA values ####
  ph = ph.rast[!is.na(ph.rast[])]
  hum = soc.rast[!is.na(soc.rast[])]
  clay = clay.rast[!is.na(clay.rast[])]
  
  #### create dummy tables for CaO and supply levels with same length as input tables ####
  cao = hum
  cao[1:length(cao)] = NA
  
  vst = hum
  vst[1:length(vst)] = NA
  
  #### calculate CaO amounts and VDLUFA lime supply levels ####
  
  for (k in 1:length(clay)) {
    
    #### initial clay and humus values ####
    
    # k <- 1
    
    x = clay[k]
    y = hum[k]
    
    #### estimate current lime supply level for each raster cell ####
    
    #### pH for lime supply level A (based on clay and humus content) ####
    
    a = 4.44503038493437165
    b = 0.0611630214437609747
    c = -0.0686795665823204359
    d = -0.000581040069975073059
    e = 0.000464112680553074486
    f = -0.00157906877363529084
    g = -6.05637040273542415e-06
    h = 2.99882946632868851e-05
    i = 5.37518553321574971e-06
    j = 2.14154100674489575e-05
    
    VstA = a + b * x + c * y + d * x^2 + e * y^2 + f * x * y + g * x^3 + h * y^3 + i * x * y^2 + j * x^2 * y
    VstA
    
    #### pH for lime supply level B (based on clay and humus content) ####
    
    a = 4.54503038493437144
    b = 0.0611630214437611172
    c = -0.0686795665823207161
    d = -0.000581040069975080914
    e = 0.000464112680553116245
    f = -0.00157906877363529713
    g = -6.05637040273530206e-06
    h = 2.99882946632855744e-05
    i = 5.37518553321594869e-06
    j = 2.14154100674489604e-05
    
    VstB = a + b * x + c * y + d * x^2 + e * y^2 + f * x * y + g * x^3 + h * y^3 + i * x * y^2 + j * x^2 * y
    VstB
    
    #### pH for lime supply level C (based on clay and humus content) ####
    
    a = 5.38395862010605336
    b = 0.101924236751260807
    c = -0.149964179613547359
    d = -0.00251757990982230612
    e = 0.00716445299579071956
    f = -0.00141452058998303312
    g = 2.05441239033212441e-05
    h = -0.000138978771257916883
    i = 2.04415637246551504e-05
    j = 1.4522740624957793e-05
    
    VstC = a + b * x + c * y + d * x^2 + e * y^2 + f * x * y + g * x^3 + h * y^3 + i * x * y^2 + j * x^2 * y
    VstC
    
    #### pH for lime supply level D (based on clay and humus content) ####
    
    a = 5.81407729513820389
    b = 0.12241997166741464
    c = -0.149964179613547596
    d = -0.00258389043572285305
    e = 0.00716445299579074784
    f = -0.00141452058998303478
    g = 1.70531411222853478e-05
    h = -0.000138978771257917656
    i = 2.0441563724655074e-05
    j = 1.45227406249578792e-05
    
    VstD = a + b * x + c * y + d * x^2 + e * y^2 + f * x * y + g * x^3 + h * y^3 + i * x * y^2 + j * x^2 * y
    VstD
    
    #### pH for lime supply level E (based on clay and humus content) ####
    
    a = 6.14612995933709175
    b = 0.123451745926766674
    c = -0.119657128577279518
    d = -0.00266824271314061795
    e = 0.00240898563042210526
    f = 5.77914443249206716e-05
    g = 1.91343834721274632e-05
    h = 1.39332406808196283e-05
    i = -2.33448646457783361e-05
    j = -5.34888478481523488e-06
    
    VstE = a + b * x + c * y + d * x^2 + e * y^2 + f * x * y + g * x^3 + h * y^3 + i * x * y^2 + j * x^2 * y
    VstE
    
    #### print supply level ####
    
    # print(paste("lime supply level A = ", round(VstA, 2), sep=""))
    # print(paste("lime supply level B = ", round(VstB, 2), sep=""))
    # print(paste("lime supply level C = ", round(VstC, 2), sep=""))
    # print(paste("lime supply level D = ", round(VstD, 2), sep=""))
    # print(paste("lime supply level E = ", round(VstE, 2), sep=""))
    # print(paste("actual pH = ", round(ph[k], 2), sep = ""))
    
    #### estimate CaO values for each raster cell ####
    #### supply level A and B ####
    
    if (ph[k] < VstC) {
      
      # print("supply level A/B")
      
      a = 46.23221401 + 20.91221641 * x + 19.40903545 * y + -0.22204017 * x^2 + -0.82685997 * y^2 + -0.88170915 * x * y - 0.00029597 * x^3 - 0.00201404 * y^3 + 0.007850146 * x * y^2 + 0.006930195 * x^2 * y
      
      b = -8.69582181 + -3.05696582 * x - 4.42559663 * y + 0.039791617 * x^2 + 0.180079369 * y^2 + 0.115560901 * x * y + -0.000090789 * x^3 + 0.000609917 * y^3 - 0.00096477 * x * y^2 - 0.00086832 * x^2 * y
      
      cao[k] = a + b * ph[k]
      
    }
    
    #### supply level C ####
    
    if (ph[k] >= VstC & ph[k] < VstD) {
      
      # print("supply level C")
      
      a = 3.39184983615217673
      b = 1.06450738602563823
      c = -0.457745647077577225
      d = -0.0182027847805315173
      e = 0.041804633905348834
      f = -0.0215060827220853108
      g = 6.98764515030589022e-05
      h = -0.00109768474805235196
      i = -0.000481974471881687996
      j = 0.000452020166495656875
      
      cao.tot = a + b * x + c * y + d * x^2 + e * y^2 + f * x * y + g * x^3 + h * y ^ 3 + i * x * y^2 + j * x^2 * y
      cao.tot
      
      # linear decrease of the applied CaO amount
      # for the pH range of the supply level C
      #
      #  CaO (dt/ha)
      #   ^
      # 20|
      #   |-------- Standard amount for level C (e.g 17)
      # 15|\
      #   | \
      # 10|  \
      #   |   \
      #  5|    \
      #   |     \
      #  0|,,,,,,\_> pH
      #   5.8   6.3
      
      cao[k] = cao.tot - cao.tot * (ph[k] - VstC) / (VstD - VstC)
      
    }
    
    #### supply level D and E ####
    
    if (ph[k] >= VstD) {
      
      # print("supply level D/E")
      
      cao[k] = 0
      
    }
    
    #### esimtate lime supply level for each raster cell ####
    
    if (ph[k] < VstA) {
      
      vst[k] = 1 # supply level A
      
    }
    
    if (ph[k] >= VstA & ph[k] < VstB) {
      
      vst[k] = 1 # supply level A
      
    }
    
    if (ph[k] >= VstB & ph[k] < VstC) {
      
      vst[k] = 2 # supply level B
      
    }
    
    if (ph[k] >= VstC & ph[k] < VstD) {
      
      vst[k] = 3 # supply level C
      
    }
    
    if (ph[k] >= VstD & ph[k] < VstE) {
      
      vst[k] = 4 # supply level D
      
    }
    
    if (ph[k] >= VstE) {
      
      vst[k] = 5 # supply level E
      
    }
    
    #####
    
  }
  
  #### level stepless CaO dt/ha ####
  
  # create dummy cao.rast
  cao.rast = clay.rast
  
  # write CaO values of cao table to raster cells which are not NA
  cao.rast[!is.na(cao.rast[])] = cao
  
  #cao.rast <- round(cao.rast * 100, 0)
  names(cao.rast) <- c("CaO")
  
  #### lime supply levels ####
  
  # create dummy vst.rast
  vst.rast <- clay.rast
  
  # write supply level number of vst_tab table to raster cells which are not NA
  vst.rast[!is.na(vst.rast[])] <- vst
  
  #### create final data set ####
  
  # create raster stack with all data
  # names(soc.rast) <- "SOM"
  # names(ph.rast) <- "pH"
  # names(clay.rast) <- "Clay"
  # names(vdl.rast) <- "Soil"
  # names(vst.rast) <- "LSL"
  
  soc.rast <- round(soc.rast, digits = 1)
  ph.rast <- round(ph.rast, digits = 1)
  clay.rast <- round(clay.rast, digits = 2)
  vdl.rast <- round(vdl.rast, digits = 0)
  cao.rast <- round(cao.rast, digits = 2)
  vst.rast <- round(vst.rast, digits = 0)
  
  names(vst.rast) <- c("pH_Klasse_num")
  names(vdl.rast) <- "VDLUFA_BG"
  names(soc.rast) <- "Humus"
  names(ph.rast) <- "pH"
  names(clay.rast) <- "Ton"
  names(cao.rast) <- c("CaO")
  
  result <- stack(soc.rast, ph.rast, clay.rast, vdl.rast, vst.rast, cao.rast)
  names(result) <- c("SOM", "pH", "Clay", "Soil", "LSL", "CaO")
  
  result <- result[[c("CaO", "LSL", "Soil", "pH", "SOM", "Clay")]]
  
  #### return results ####
  
  return(result)
  
}
