
# Color scales for SOM (Humus) ----
color_humus1 <- c("#FFF7BC","#FEC44F","#FE9929","#EC7014","#CC4C02","#993404","#662506","#238443")
color_humus2 <- c("#ffff73","#FEFDC0","#FFC780","#FEAA00", "#A87000","#734D00","#403200","#737300")

gg_raster_humus_discrete <- function(data, sub = "", col = color_humus1){
  humus.df <- raster::as.data.frame(data, xy = TRUE)
  humus.df <- na.omit(humus.df)
  colnames(humus.df)[3] <- "Humus"
  humus.df$brks <- cut(humus.df$Humus,
                       breaks=c(0,1,2,3,4,8,15,30,100),
                       labels=c("0 - 1", "1 - 2", "2 - 3",
                                "3- 4", "4 - 8", "8 - 15",
                                "15 - 30","> 30"))
  humus.karte <-
    ggplot()+
    geom_raster(aes(x=x, y=y, fill=brks), alpha=1, data = humus.df)+
    coord_equal()+
    scale_fill_manual(values = col, drop=FALSE)+
    labs(title = "Humuskarte",
         subtitle = sub,
         caption = "Data source: ph-BB; Projektion: UTM ETRS89 33N",
         fill= "Humus [%]",
         x="Easting [m]",
         y="Norhing [m]")+
    theme_bw()
  return(humus.karte)
}
